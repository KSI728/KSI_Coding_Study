# 패킹(packing) / 언패킹(unpacking)
# 패킹 : 데이터가 싸여져 있는 것 => list tuple dict set
# 언패킹 : 데이터들을 각각 하나의 변수에 따로 따로 저장하는 것

# 패킹(packing) 방식 
nums=[1,3,5]
datas=6,7,8

# 언패킹(Unpacking) 방식
a,b,c=[1,3,5]
print(a)

# [언패킹 예시]
cat={'검정':'네로','화이트':'하양이'}
items=cat.items()
for k,v in items:
    print(f'{k} -> {v}')

# 문법상 원소 개수만큼 변수 지정, 사용되지 않는 데이터 저장 변수명 '_'
a1, a2, a3 = 10, 20, 30
a1, a2, _ = 10, 20, 30
*a1, _ = 10, 20, 30
print(a1, _)
