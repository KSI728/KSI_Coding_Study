## ------------------------------------------------------
## Flask APP Entry Point File
## [예시] 로그인 및 로그아웃
## ------------------------------------------------------
## 모듈 로딩 
## ------------------------------------------------------
from flask import Flask
from flask import render_template, request 
from flask import session, redirect, url_for



## ------------------------------------------------------
## 전역 변수
## ------------------------------------------------------
APP = Flask(__name__)


## ------------------------------------------------------
## Flask 세션을 위한 시크릿 키
# os.urandom(24) : 암호학적으로 안전한 랜덤 바이트를 생성
# APP.secret_key = 'super-secret-key-{os.urandom(24)}'
## ------------------------------------------------------
APP.secret_key = 'super-secret-key-123456789!'


## ------------------------------------------------------

## ------------------------------------------------------
## 처리 URL Rule : http://127.0.0.1:5000 URL 요청 처리 부분 
## 처리 view 함수 : index()
## ------------------------------------------------------
@APP.route("/")         
def index():
    if 'username' in session:
        user_name = session.get('username')
        return render_template("user_page.html", name=user_name)
    else:
        return render_template('login.html')


## ------------------------------------------------------
## 처리 URL Rule : http://127.0.0.1:5000/login URL 요청 처리 부분
## 처리 view 함수 : login()
## ------------------------------------------------------
@APP.route('/login', methods=['POST'])
def login():
    # login.html에 <form> 태그 아래 <input> 태그 중
    # name 속성값이 'username'인 <input> 태그에 입력한 값
    username = request.form.get('username')
    if username:
        session['username'] = username
        # 로그인 후 세션에 저장 => 사용자 화면 이동 
        # redirect(URL_String)
        # redirect(url_for(endpoint))
        return redirect(url_for('index'))
    

## -----------------------------------------------------
## 처리 URL Rule : http://127.0.0.1:5000/logout URL 
## 처리 view 함수 : logout()
 ## -----------------------------------------------------
@APP.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))


## -----------------------------------------------------
## 처리 URL Rule : http://127.0.0.1:5000/check-session URL 
## 처리 view 함수 : check_session()
 ## -----------------------------------------------------
@APP.route('/check-session')
def check_session():
    user = session.get('username')
    if user:
        return f'현재 로그인 사용자: {user}'
    else:
         return '로그인한 사용자가 없습니다.'


## ------------------------------------------------------
## 조건에 따른 실행 처리 
## ------------------------------------------------------
if __name__ == '__main__':
    APP.run()   ## Flask Web Server 구동 