
public class Car {
	//필드 선언 : 멤버 변수(필드)는 반드시 클래스 선언 바로 아래에 정의함
	//멤버 변수는 클래스 내부 메소드 어디에서든 사용 가능
	//클래스 내부의 전역 변수 역할 
	String model;
	boolean start;
	int speed;
	
	//생성자
	public Car() {
		model = "model";
		start = false;
		speed = 0;
	}
	
	//메소드
	public void displayCarName() {
		// int num1 = 10;  지역변수
		for (int i=0; i<10; i++) {
			System.out.println(model + i);
		 }
	
	 }

}
