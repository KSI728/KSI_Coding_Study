# dict 자료형
# 형식 : {key1:value, key2:value, ...}
# 데이터를 식별하는 key와 함께 저장
# key로 데이터를 식별하기 때문에 인덱스가 필요하지 않음
# key가 중복될 경우 가장 뒤에 있는 값만 사용함
# key에는 리스트와 딕셔너리를 사용할 수 없음 

# [1] dict 데이터 생성
data1={}
data2={'cat':3,'dog':2}
print(type(data2));print(len(data2))

data3={("animal",):{'고양이':3},1:{'강아지':2},4:[1,2,3]} # list 타입은 value만 가능
print(type(data3));print(len(data3))

# [2] dict에서 원소/요소 읽기 => 변수명[key]
data2={'cat':3,'dog':2}
print(data2['cat'])

# [3] dict에서 원소/요소 값 변경 => 변수명[key]=새로운 값
data2={'cat':3,'dog':2}
data2['dog']=7
print(data2)

# [4] dict에서 원소/요소 값 삭제 => del 변수명[key]
del data2['cat']
print(data2)

# [5] dict에서 원소/요소 추가 => 변수명[key]=값
# 단, 존재하지 않는 key의 경우 추가, 존재하고 있는 key면 변경
data2['duck']=6
print(data2)