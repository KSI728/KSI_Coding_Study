# 문자열 str 타입 슬라이싱
# 전체 문자열에서 일정한 간격으로 연속된 문자열을 일부 추출하는 방법
# 문법 : 변수명[시작인덱스:끝인덱스+1:증감/간격]
#      + 변수명[:끝인덱스+1] : 처음부터 끝인덱스 까지
#      + 변수명[시작인덱스:] : 시작인덱스부터 끝인덱스까지
#      + 변수명[:] : 처음부터 끝까지

msg2="Happy New Year 2025! Merry Christmas ★"
print(msg2[15:18],msg2[15:19])
# 구간을 정할 경우 맨 마지막 인덱스는 +1 해줘야 함

msg="Life is too short, you need Python!"
print(msg[-7:])
print(msg[:4])
print(msg[:])
print(msg[::-1])
print(msg[::2])

# [문제]
question="A123B123C123D999"
print(question[::4])