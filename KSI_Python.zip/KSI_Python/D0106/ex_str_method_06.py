# 메서드(method) : str 타입 전용 함수
# 문법 : 변수명.메서드명()

# [11] lstrip(), rstrip(), strip()
# 앞부분 공백 제거 / 끝부분 공백 제거 / 앞부분, 끝부분 공백 제거
data="  happy  "
print(data.lstrip())
print(data.rstrip())
print(data.strip())

# [실습] 입력 데이터 여부 체크 
data1=input("댓글입력 : ").strip()
print(f'데이터 입력 여부 : {len(data1)}개 입력됨')