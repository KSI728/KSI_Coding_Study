# [문제 1]
city="Daegu"
blood='A'
season="Fall"
height=171
phone="010-9272-9883"
pi=3.14
nationality="Korea"

# [문제 2]
multiple=int(input("궁금한 구구단 : "))
print(f'{multiple} * 1 = {multiple*1}')
print(f'{multiple} * 2 = {multiple*2}')
print(f'{multiple} * 3 = {multiple*3}')
print(f'{multiple} * 4 = {multiple*4}')
print(f'{multiple} * 5 = {multiple*5}')
print(f'{multiple} * 6 = {multiple*6}')
print(f'{multiple} * 7 = {multiple*7}')
print(f'{multiple} * 8 = {multiple*8}')
print(f'{multiple} * 9 = {multiple*9}')

# [문제 3]
# 1
num31=31
float(num31)
# 2
num31=float(31)
# 3
num2022=2022
str(num2022)
# 4
num2022=str(num2022)
# 5
float981=98.1
int(float981)
# 6
float981=int(float981)
# 7 
float981=98.1
str(float981)
# 8
float981=str(float981)

# [문제 4]
# 1
code="881120-1068234"
print(code[:6])
print(code[7:])
# 2
string="a:b:c:d"
print(string[0])
print(string[2])
print(string[4])
print(string[6])
# 3
cost=str(48584*36)
cost2=cost[0]+','+cost[1:4]+','+cost[4:]
print(f'에어컨 금액 : {cost2}원')
# 4
square="가로 10cm, 세로 11cm인 직사각형 넓이 계산"
print(f'직사각형 넓이 : 가로 {square[3:5]} x 세로 {square[12:14]} = {int(square[3:5])*int(square[12:14])}')

# [문제 5]
# 1
path="C:\\Users\\Public\\kyobo\\eLibrary\\B2C\\edir.info"
print(f'경로 : {path}')
# 2
data=[99,-5,100,0,72]
print(f'가장 큰 값 : {max(data)}')
print(f'가장 작은 값 : {min(data)}')
print(f'절대값 : {abs(data[0])} {abs(data[1])} {abs(data[2])} {abs(data[3])} {abs(data[4])}')
# 3
print("오늘은 \"2025년 1월 1일 새해\" 입니다.")

# [문제 6]
print('''하늘과 바람과 별과 시\n\t서시(序詩)\n\t\t\t윤동주\n
죽는 날까지 하늘을 우러러\n한 점 부끄럼이 없기를,\n잎새에 이는 바람에도\n나는 괴로워했다.
별을 노래하는 마음으로\n모든 죽어가는 것을 사랑해야지\n그리고 나한테 주어진 길을
걸어가야겠다.\n \n오늘 밤에도 별이 바람에 스치운다.''')
