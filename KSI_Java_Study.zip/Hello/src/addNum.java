import java.util.Scanner;

public class addNum {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//객체 변수 new: 객체 생성
		int result = 0;
		
		System.out.print("첫 번째 정수를 입력");
		String strX = scanner.nextLine();
		int x = Integer.parseInt(strX);
		// int x = scanner.nextInt();
		
		System.out.print("두 번째 정수를 입력");
		int y = scanner.nextInt();
		
		System.out.print("세 번째 정수를 입력");
		int z = scanner.nextInt();
		
		result = x + y + z;
		
		System.out.println("결과 : " + result);
		scanner.close();

	}

}
