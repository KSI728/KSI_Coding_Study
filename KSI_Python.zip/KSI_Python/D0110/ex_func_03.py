# 특정 기능 수행 코드의 재사용을 위한 방법 = 함수(Function)
# - 자주 사용되는 기능의 코드를 묶음
# - 이 코드를 1번만 작성해서 필요할때 마다 사용함

# [ 리턴값이 여러 개인 함수 ]
# 함수기능 : 2개 정수에 대한 사칙연산 결과 반환 기능
# 함수이름 : asmd
# 매개변수 : num1, num2
# 반환값 : 사칙연산 결과

def asmd(num1,num2):
    plus=num1+num2;minus=num1-num2;multi=num1*num2
    divide=num1/num2 if num2 else '0으로 나눌 수 없음'
    return plus, minus, multi, divide

# 함수 호출
print(asmd(8,4))
a,b,c,d=asmd(8,4)
print(f"덧셈 : {a}")
print(f"뺄셈 : {b}")
print(f"곱셈 : {c}")
print(f'나눗셈 : {d}')