# 가변인자 함수
# 매개변수 개수 : 0개 ~ n개
# 문법 / 형식 : def 함수이름(*매개변수명)
# 매개변수의 타입 : tuple

# [예제] 중간고사 여러 과목 점수에 대한 합계와 평균을 출력하는 함수
# 함수기능 : N개의 과목 점수에 대한 합계와 평균 출력
# 함수이름 : sum_avg()
# 매개변수 : *score
# 함수결과 : 합계와 평균
def sum_avg(*score):
    total=sum(score)
    avg=total/len(score) if len(score) else 0
    return total, avg

print(sum_avg(100,90,80,70))

#------------------------------------------------------------------------------
# 함수기능 : n개 정수 덧셈 후 결과 반환 기능
# 함수이름 : add_n()
# 매개변수(가변인자) : num n개(0~n개까지 가능한 매개변수)
# 반환값 : n개 덧셈 결과

def add_n(*nums): # [*을 붙이면 n개 라는 의미]
    for i in nums:
        total=sum(nums)
        return total
print(add_n(3,5,6,5))