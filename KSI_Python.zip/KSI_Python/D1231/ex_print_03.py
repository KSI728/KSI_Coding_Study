# f스트링 문자열
# 문법 : f'{변수명}, {변수명}'

name="한끼만"
age=20
print(f'이름은 {name}, 나이는 {age}살')

# [실습]
num1=10
num2=3
print(f'{num1}+{num2}={num1+num2}')
print(f'{num1}-{num2}={num1-num2}')