# for ~ in 반복문

# 구구단 출력하기
dan=9
for num in range(1,10):
    print(f'{dan} * {num} = {dan*num}')
    
# 구구단 출력하기 (2단 ~ 9단)
for dan in range(2,10):
    print(f'\n---{dan}단---')
    for num in range(1,9):
        print(f'{dan} * {num} = {dan*num}')
    
