# 함수 기능 : DataFrame의 컬럼별 고유값 개수와 고유값 출력
# 함수 이름 : check_unique()
# 매개 변수 : df
# 반환값 : 없음

def check_unique(df):
    for i in df.columns:
        print(f'[ {i}의 고유값 ]')
        print(df[i].unique(), end='\n\n')