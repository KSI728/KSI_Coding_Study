import numpy as np

# Numpy ndarray 1차원 변환
# flatten() 함수 / 메서드 : 다른 메모리 공간에 저장
# ravel() 함수 / 메서드 : 동일 데이터 메모리 공유
    
n1 = np.array([[10,20], [30,40], [50,60]])
print(n1)

# 1차원 변환 - flatten()
n1 = n1.flatten()
print(n1)

print('-------------------------------------')

# 1차원 변환 - ravel()
# 원본 ndarray 데이터 변경 시 ravel() 저장된 데이터도 변경됨  
n1 = np.array([[10,20], [30,40], [50,60]])
n1 = n1.ravel()
print(n1)