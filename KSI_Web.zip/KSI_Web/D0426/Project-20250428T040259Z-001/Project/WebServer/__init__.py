# --------------------------------------------------------------------------------
# Flask Framework에서 WebServer 구동 파일
# - 파일명 : __init__.py
# --------------------------------------------------------------------------------

# 모듈 로딩
from flask import Flask
from flask_migrate import Migrate           ## DB관련
from flask_sqlalchemy import SQLAlchemy     ## DB관련

# DB관련 설정
import config 

# DB에 제어하기위한 인스턴스 
DB = SQLAlchemy()
MIGRATE = Migrate()

# --------------------------------------------------------------------------------
# Application 생성 함수
# - 함수명 : create_app <= 이름 변경 불가!!
# 사용자 정의 함수
# --------------------------------------------------------------------------------

def create_app():
    # 전역 변수
    # Flask Web Server 인스턴스 생성
    app = Flask(__name__)

    # --------------------------------------------------------------
    # DB 관련 초기화 설정 : config.py 파일 읽어서 웹 서버에 설정 구성
    app.config.from_object(config)
    
    # DB 초기화 및 연동
    DB.init_app(app)
    MIGRATE.init_app(app, DB)

    # DB 클래스 정의 모듈 => flask의 migrate 기능 인식 위해 추가
    # => flask db migrate 명령어 실행
    #    - revision파일 생성 (예: versions폴더 아래 18634a293520_.py)
    # => flask db upgrade 명령어 실행
    #    - revison 파일 내용 기반 table 생성  
    from .models import models

    # --------------------------------------------------------------

    ## 라우팅 등록
    from .views import main_view, user_view
    from .views import question_view, detail_view, answer_view
    app.register_blueprint(main_view.main_bp)
    app.register_blueprint(user_view.user_bp)
    app.register_blueprint(question_view.question_bp)
    app.register_blueprint(detail_view.detail_bp)
    app.register_blueprint(answer_view.answer_bp)

    ## Flask Server 인스턴스 반환
    return app
