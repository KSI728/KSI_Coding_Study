package java_practice;

public record Member1 (String id, String name, int age) {
	
	@Override
	public String toString() {
		return "Member1: [" + id + ", "
		+ name + ", " + age + "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Member1 target) {
			if(this.name.equals(target.name) && this.age == target.age)
				return true;
		}
		return false;
	}
	
}