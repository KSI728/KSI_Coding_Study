# 101~110
# bool 타입
# False
# True
# True
# True
# 비교연산자가 아님
# 출력하지 않음
# "Hi, there."을 출력
# 1,2,4를 출력
# 3,5를 출력

# 111~120
# 111
msg="hello";print(msg*2)
# 112
num=30;print(num+10)
# 113
num=int(input());print("짝수") if num%2==0 else print("홀수")
# 114
num=int(input())
if num+20<255:
    print(num+20)
else:
    print(255)
# 115
num=int(input())
if num-20<0:
    print(0)
elif num-20>255:
    print(255)
else:
    print(num-20)
116
time=input().strip()
if time=='02:00':
    print('정각 입니다.')
else: 
    print('정각이 아닙니다.')
# 117
fruit=["apple", "grape", "persimmon"]
like=input().strip()
if like=='apple':
    print("정답입니다.")
else:
    print("오답입니다.")
# 118
warn_investment_list=["Microsoft", "Google", "Naver", "Kakao", "SAMSUNG", "LG"]
cc=input().strip()
if cc in warn_investment_list:
    print("투자 경고 종목입니다.")
else: 
    print("투자 경고 종목이 아닙니다.")
# 119
fruit={"봄" : "딸기", "여름" : "토마토", "가을" : "사과"}
likes=input().strip()
if likes in fruit.keys():
    print('정답입니다.')
else:
    print('오답입니다.')
# 120   
fruit = {"봄" : "딸기", "여름" : "토마토", "가을" : "사과"}
likes=input().strip()
if likes in fruit.values():
    print('정답입니다.')
else:
    print('오답입니다.')

# 121~130
# 121
a=input()
if a.isupper():
    print(a.lower())
elif a.islower():
    print(a.upper())
# 122
score=int(input().strip())
if score<=100 and score>=81:
    print('A')
elif score<=80 and score>=61:
    print('B')
elif score<=60 and score>=41:
    print('C')
elif score<=40 and score>=21:
    print('D')
else:
    print('E')
# 123
money=input().split(' ')
money[0]=int(money[0])
if money[1]=='달러':
    print(money[0]*1167)
elif money[1]=='엔':
    print(money[0]*1.096)
elif money[1]=='유로':
    print(money[0]*1268)
elif money[1]=='위안':
    print(money[0]*171)
# 124
num1=int(input())
num2=int(input())
num3=int(input())
num4=[num1,num2,num3]
print(max(num4))
# 125
phone=input("휴대전화 번호 입력 : ")
if phone.startswith('011'):
    print("SKT")
elif phone.startswith('016'):
    print("KT")
elif phone.startswith('019'):
    print("LGU")
elif phone.startswith('010'):
    print("알수없음")
# 126
post=input('우편번호 : ')
if post[2] in ['0','1','2']:
    print('강북구')
elif post[2] in ['3','4','5']:
    print('도봉구')
elif post[2] in ['6','7','8','9']:
    print('노원구')
# 127
jumin=input("주민등록번호 : ")
if jumin[7] in ['1','3']:
    print('남자')
elif jumin[7] in ['2','4']:
    print('여자')
# 128
jumin=input("주민등록번호 : ").split('-')
back=jumin[1]
if int(back[1:3])<=8:
    print('서울 입니다.')
else:
    print('서울이 아닙니다.')
# 129
jumin=input("주민등록번호 : ")
result1=int(jumin[0])*2+int(jumin[1])*3+int(jumin[2])*4+int(jumin[3])*5+int(jumin[4])*6+int(jumin[5])*7+int(jumin[7])*8+int(jumin[8])*9+int(jumin[9])*2+int(jumin[10])*3+int(jumin[11])*4+int(jumin[12])*5
result2=11-(result1%11)
result2=str(result2)

if jumin[-1]==result2[-1]:
    print("유효한 주민등록번호입니다.")
else:
    print("유효하지 않은 주민등록번호입니다.")
# 130
# import requests 가 동작하지 않음

# 131~140
# 131
# 사과, 귤, 수박이 차례대로 출력됨
# 132
# #####이 3번 출력됨
# 133
a="A";print(a)
b="B";print(b)
c="C";print(c)
# 134
a="A";print("출력 : ",a)
b="B";print("출력 : ",b)
c="C";print("출력 : ",c)
# 135
a="A";print(a.lower())
b="B";print(b.lower())
c="C";print(c.lower())
# 136
for i in [10,20,30]:
    print(i)
# 137
for i in [10,20,30]:
    print(i)
# 138
for i in [10,20,30]:
    print(i)
    print("--------")
# 139
for i in ["++++",10,20,30]:
    print(i)
# 140
for i in range(4):
    print("--------")

# 141~150
# 141
list=[100,200,300]
for i in list:
    print(i+10)
# 142
list=["bap", "ramen", "t"]
for i in list:
    print('오늘의 메뉴 :',i)
# 143
list=["SK", "SAMSUNG", "LG"]
for i in list:
    print(len(i))
# 144
list=['dog', 'cat', 'parrot']
for i in list:
    print(i,len(i))
# 145
list=['dog', 'cat', 'parrot']
for i in list:
    print(i[0])
# 146
list=[1,2,3]
for i in list:
    print("3 x",i)
# 147
list=[1,2,3]
for i in list:
    print("3 x",i,'=',3*i)
# 148
list=["가", "나", "다", "라"]
for i in list[1:]:
    print(i)
# 149
list=["가", "나", "다", "라"]
for i in list[::2]:
    print(i)
# 150
list=["가", "나", "다", "라"]
for i in list[::-1]:
    print(i)

# 151~160
# 151
list=[3, -20, -3, 44]
for i in list:
    if i<0:
        print(i)
# 152
list=[3, 100, 23, 44]
for i in list:
    if i%3==0:
        print(i)
# 153
list=[13, 21, 12, 14, 30, 18]
for i in list:
    if i%3==0 and i<20:
        print(i)
# 154
list=["I", "study", "python", "language", "!"]
for i in list:
    if len(i)>=3:
        print(i)
# 155
list=["A", "b", "c", "D"]
for i in list:
    if i.isupper():
        print(i)
# 156
list=["A", "b", "c", "D"]
for i in list:
    if i.islower():
        print(i)
# 157
list=['dog', 'cat', 'parrot']
for i in list:
    print(i.capitalize())
# 158
list=['hello.py', 'ex01.py', 'intro.hwp']
for i in list:
    i_split=i.split('.')
    print(i_split[0])
# 159
list=['intra.h', 'intra.c', 'define.h', 'run.py']
for i in list:
    if i.endswith('.h'):
        print(i)
# 160
list=['intra.h', 'intra.c', 'define.h', 'run.py']
for i in list:
    if i.endswith('.h') or i.endswith('.c'):
        print(i)

# 161~170
# 161
for i in range(100):
    print(i)
# 162
for i in range(2002,2051,4):
    print(i)
# 163
for i in range(1,31):
    if i%3==0:
        print(i)
# 164
for i in range(100):
    print(99-i)
# 165
for i in range(10):
    print(i/10)
# 166
for i in range(1,10):
    print(f'3x{i}={i*3}')   
# 167
for i in range(1,10,2):
    print(f'3x{i}={i*3}')  
# 168 
ilist=[]
for i in range(1,11):
    ilist.append(i)
print(sum(ilist))
# 169
ilist=[]
for i in range(1,11,2):
    ilist.append(i)
print(sum(ilist))
# 170
result=1
for i in range(1,11):
    result*=i
print(result)
    
# 171~180
# 171
price_list=[32100, 32150, 32000, 32500]
for i in range(4):
    print(price_list[i])
# 172
price_list=[32100, 32150, 32000, 32500]
for i in range(4):
    print(i, price_list[i])
# 173
for i in range(len(price_list)):
    print((len(price_list)-1)-i, price_list[i])
# 174
price_list=[32100, 32150, 32000, 32500]
for i in range(1,4):
    print(90+10*i, price_list[i])
# 175
my_list=["가", "나", "다", "라"]
for i in range(len(my_list)-1):
    print(my_list[i],my_list[i+1])
# 176
my_list=["가", "나", "다", "라","마"]
for i in range(len(my_list)-2):
    print(my_list[i],my_list[i+1],my_list[i+2])
# 177
my_list=["가", "나", "다", "라"]
for i in range(len(my_list)-1,0,-1):
    print(my_list[i],my_list[i-1])
# 178
my_list=[100, 200, 400, 800]
for i in range(len(my_list)-1):
    print(my_list[i+1]-my_list[i])
# 179
my_list=[100, 200, 400, 800, 1000, 1300]
for i in range(len(my_list)-2):
    print((my_list[i]+my_list[i+1]+my_list[i+2])/3)
# 180
low_prices=[100, 200, 400, 800, 1000]
high_prices=[150, 300, 430, 880, 1000]
volatility=[]
for i in range(5):
    volatility.append(high_prices[i]-low_prices[i])
print(volatility)

# 181~190
# 181
apart=[['101호','102호'],['201호','202호'],['301호','302호']]
# 182
stock=[['시가',100,200,300], ['종가',80,210,330]]
# 183
stock={'시가':[100,200,300], '종가':[80,210,330]}
# 184
stock={'10/10':[80,110,70,90], '10/11':[210,230,190,200]}
# 185
apart = [ [101, 102], [201, 202], [301, 302] ]
for i in apart:
    for k in i:
        print(k, '호')
# 186
apart=[ [101, 102], [201, 202], [301, 302] ]
for i in apart[::-1]:
    for k in i:
        print(k, '호')
# 187
apart=[ [101, 102], [201, 202], [301, 302] ]
for i in apart[::-1]:
    for k in i[::-1]:
        print(k, '호')
# 188
apart=[ [101, 102], [201, 202], [301, 302] ]
for i in apart:
    for k in i:
        print(k, '호')
        print('-----')
# 189
apart=[ [101, 102], [201, 202], [301, 302] ]
for i in apart:
    for k in i:
        print(k, '호')
    print('-----')    
# 190
apart=[ [101, 102], [201, 202], [301, 302] ]
for i in apart:
    for k in i:
        print(k, '호')
print('-----')    

# 191~200
# 191
data = [
    [ 2000,  3050,  2050,  1980],
    [ 7500,  2050,  2050,  1980],
    [15450, 15050, 15550, 14900]]
for i in data:
    for k in i:
        print(k+(k*0.00014))
# 192
data = [
    [ 2000,  3050,  2050,  1980],
    [ 7500,  2050,  2050,  1980],
    [15450, 15050, 15550, 14900]]    
for i in data:
    for k in i:
        print(k+(k*0.00014))
    print('-----')
# 193
data = [
    [ 2000,  3050,  2050,  1980],
    [ 7500,  2050,  2050,  1980],
    [15450, 15050, 15550, 14900]]    
result=[]
for i in data:
    for k in i:
        k=k+(k*0.00014)
        result.append(k)
print(result)
# 194
data = [
    [ 2000,  3050,  2050,  1980],
    [ 7500,  2050,  2050,  1980],
    [15450, 15050, 15550, 14900]]  
result=[]
for i in data:
    mini_result=[]
    for k in i:
        k=k+(k*0.00014)
        mini_result.append(k)
    result.append(mini_result)
print(result)
# 195
ohlc = [["open", "high", "low", "close"],
        [100, 110, 70, 100],
        [200, 210, 180, 190],
        [300, 310, 300, 310]]
for i in ohlc[1:]:
    print(i[3])
# 196
ohlc = [["open", "high", "low", "close"],
        [100, 110, 70, 100],
        [200, 210, 180, 190],
        [300, 310, 300, 310]]
for i in ohlc[1:]:
    if i[3]>150:
        print(i[3])
# 197
ohlc = [["open", "high", "low", "close"],
        [100, 110, 70, 100],
        [200, 210, 180, 190],
        [300, 310, 300, 310]]
for i in ohlc[1:]:
    if i[0]<=i[3]:
        print(i[3])
# 198
ohlc = [["open", "high", "low", "close"],
        [100, 110, 70, 100],
        [200, 210, 180, 190],
        [300, 310, 300, 310]]
volatility=[]
for i in ohlc[1:]:
    sum=i[1]-i[2]
    volatility.append(sum)
print(volatility)
# 199
ohlc = [["open", "high", "low", "close"],
        [100, 110, 70, 100],
        [200, 210, 180, 190],
        [300, 310, 300, 310]]
for i in ohlc[1:]:
    if i[3]>i[0]:
        print(i[1]-i[2])
# 200
ohlc = [["open", "high", "low", "close"],
        [100, 110, 70, 100],
        [200, 210, 180, 190],
        [300, 310, 300, 310]]
result1=0
for i in ohlc[1:]:
    result1=result1+(i[3]-i[0])
print(result1)