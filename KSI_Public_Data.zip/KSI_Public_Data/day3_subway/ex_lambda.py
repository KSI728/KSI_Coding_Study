sum=lambda a,b:a+b
print(sum(3,7))

msg="Apple Banana Cake Dragon"

# 정렬할 때 (그때만 바뀜) 문자열을 소문자로 변경 후 오름차순 정렬 
sorted_list=sorted(msg.split(),key=str.lower)
print(sorted_list)

# 정렬할 때 (그때만 바뀜) 문자열을 글자 수 기준으로 내림차순 정렬 
descending_sorted_list=sorted(msg.split(),key=len,reverse=True)
print(descending_sorted_list)

students=[('Alice',3.9,20160303),('Bob',3.0,20160302),('Charlie',4.3,20160301)]
 
# 학번(students[2])을 기준으로 오름차순 정렬
sorted_students1=sorted(students,key=lambda s:s[2])
print(sorted_students1)

# 학점(students[1])을 기준으로 내림차순 정렬
sorted_students2=sorted(students,key=lambda	s:s[1],	reverse=True)
print(sorted_students2)

# 클래스와 람다
class Student:
    
    def __init__(self,name,grade,number):
        # 클래스 내부의 멤버 변수 
        self.name=name
        self.grade=grade
        self.number=number
    
    def __repr__(self):
        return f'({self.name},{self.grade},{self.number})'
    
students=[Student('홍길동',	3.9,	20240303),
          Student('김유신',	3.0,	20240302),
          Student('박문수',	4.3,	20240301)]

# Student 클래스에 __repr__()에 정의된 형태로 출력 
print(students[0])

sorted_list=sorted(students, key=lambda s : s.name)
print(sorted_list)