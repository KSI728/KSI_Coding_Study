# [문제 1] 정수 2개 입력 받은 후 7가지 산술연산 결과를 출력
num1=int(input("정수 하나를 입력하시오 : "))
num2=int(input("정수 하나를 입력하시오 : "))
# print(f'{num1} + {num2} = {num1+num2} {bin(num1+num2)} {oct(num1+num2)} {hex(num1+num2)}')
# print(f'{num1} - {num2} = {num1-num2} {bin(num1-num2)} {oct(num1-num2)} {hex(num1-num2)}')
# print(f'{num1} * {num2} = {num1*num2} {bin(num1*num2)} {oct(num1*num2)} {hex(num1*num2)}')
# print(f'{num1} / {num2} = {num1/num2} {bin(int(num1/num2))} {oct(int(num1/num2))} {hex(int(num1/num2))}')
# print(f'{num1} // {num2} = {num1//num2} {bin(num1//num2)} {oct(num1//num2)} {hex(num1//num2)}')
# print(f'{num1} % {num2} = {num1%num2} {bin(num1%num2)} {oct(num1%num2)} {hex(num1%num2)}')
# print(f'{num1} ** {num2} = {num1**num2} {bin(num1**num2)} {oct(num1**num2)} {hex(num1**num2)}')

value1=num1+num2
value2=num1-num2
value3=num1*num2
value4=num1/num2
value5=num1//num2
value6=num1%num2
value7=num1**num2
print(f'{num1} + {num2} = {value1} {bin(value1)} {oct(value1)} {hex(value1)}')
# 사칙연산 결과를 변수에 미리 저장하는 방법도 있음 

# [문제 2] 3개 단어 입력 받은 후, 큰 단어와 작은 단어 출력 
word1=(input("단어를 하나 입력하세요 : "))
word2=(input("단어를 하나 입력하세요 : "))
word3=(input("단어를 하나 입력하세요 : "))
print(word1, word2, word3)
print(max(word1, word2, word3))
print(min(word1, word2, word3))