import numpy as np 
import pandas as pd

# Numpy - ndarray 데이터 타입 
# C언어 array를 Python으로 구현 
# !!동일한!! 데이터 타입의 데이터를 연속된 메모리 공간에 저장함 
# 적은 메모리 사용 및 빠른 처리 

# ndarray 객체 생성 
n0 = np.array(10)        # 0차원
n1 = np.array([10,20])   # 1차원
n11 = np.array([10,20], dtype = np.uint8)    # n1과 똑같은 데이터지만 용량을 적게 차지
n2 = np.array([[10,20], [30,40], [50,60]])   # 2차원

# ndarray 객체 속성 
def array_info(n1):
    
    print(f'차원 : {n1.ndim}')
    print(f'형태 : {n1.shape}')
    print(f'데이터 : {n1.data}')
    print(f'원소 : {n1.itemsize}')
    print(f'크기 : {n1.size}')
    print(f'타입 : {n1.dtype}')
    print(f'방향 : {n1.strides}') # 0차원은 아무것도 안나옴
    print(f'용량 : {n1.nbytes}')
    

    
array_info(n0)
print('-----------------------')
array_info(n1)
print('-----------------------')
array_info(n2)
print('-----------------------')
array_info(n1)
print('-----------------------')
array_info(n11)

