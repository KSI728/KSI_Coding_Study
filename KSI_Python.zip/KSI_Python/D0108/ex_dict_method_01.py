# dict 자료형 전용 함수(메서드)

data={'name':'한끼만','age':20,'job':'gambler'}

# [1] .keys()
# class가 보여주기 기능만을 지원하는 dict_keys로 출력된다.
# 따라서 keys()의 요소를 추출하기 위해서 list로 형변환 해야 한다.
keys=data.keys()
print(keys)
print(type(keys))

# [2] .values()
# dict에서 value만 추출
# class가 보여주기 기능만을 지원하는 dict_values로 출력된다.
# 따라서 마찬가지로 values()의 요소를 추출하기 위해서 list로 형변환 해야 한다.
values=data.values()
print(values)
print(type(values))

# [3] .items()
# dict에서 키와 값을 "튜플"로 묶어서 추출
# class가 보여주기 기능만을 지원하는 dict_items로 출력된다.
# 따라서 마찬가지로 items()의 요소를 추출하기 위해서 list로 형변환 해야 한다.
items=data.items()
print(items)
print(type(items))

# [4] .get(key) / .get(key, defalut value)
# dict에서 키로 값 추출해주는 메서드 
# 존재하지 않는 key를 입력했을때 나타나는 디폴트 값을 key, 뒤에 입력 가능
print(data.get('haircolor')) #None
print(data.get('haircolor','red')) #디폴트 값으로 'red' 지정

# [5] 멤버 연산자 in, not in
# key
print('age' in data)
# value
print('한끼만' in data.values()) #.values() 사용해야 함