# [문제 1]
# 자료형(데이터 타입)은 데이터를 특징에 따라 분류한 것이다.

# [문제 2]
'''
[대표적인 자료형]
1. int 타입 
 (예시) 1, 2 (양수) / 0 / -1, -2 (음수) 등
 (출력 방법) int()
2. float 타입
 (예시) 1.23, 23.0 (실수) 등
 (출력 방법) float()
3. str 타입
 (예시) "abc", 'a'(파이썬에서는 단일 문자도 문자열) 등
 (출력 방법) str()
4. bool 타입
 (예시) True, False 
 (출력 방법) bool()
5. 다른 타입들
 complex(복소수) 타입 / bytes 타입
'''

# [문제 3]
print(bin(31))
print(oct(31))
print(31)
print(hex(31))

# [문제 4]
average=98.7
int(average) # 데이터 손실 발생

year=2022
float(year)

greeting="Hello~"
bool(greeting) # 0이 아니므로 True

# [문제 5]
num1=int(input("숫자 1 입력 : "))
num2=int(input("숫자 2 입력 : "))
print(f'덧 셈 {num1} + {num2} = {num1+num2}')
print(f'뺄 셈 {num1} - {num2} = {num1-num2}')
print(f'곱 셈 {num1} * {num2} = {num1*num2}')
print(f'나눗셈 {num1} / {num2} = {num1/num2}')
print(f'몫 {num1} // {num2} = {num1//num2}')
print(f'나머지 {num1} % {num2} = {num1%num2}')
print(f'제곱근 {num1} ** {num2} = {num1**num2}')

# [문제 6]
msg=input("문자 1개 입력 : ")
print(f'{msg} 코드값 : {ord(msg)}  {msg} 기계어 : {bin(ord(msg))}')
