# [문제 1]
nums=[13,21,12,14,30,18]
# 1-1
for pp in nums:
    print(pp, end=' ')
print()
# 1-2
for even in nums:
    if even%2==0:
        print(even, end=' ')
print()
# 1-3
print(sum(nums), sum(nums)/len(nums))   
# 1-4
nums.sort(reverse=True)
print(nums)

# [문제 2]
words=["I","study","python","language","!"]
# 2-1
for ww in words:
    print(ww, end=" ")
print()
# 2-2
for h in words[::2]:
    print(h, end=" ")
print()
# 2-3
for l in words:
    if len(l)>=3:
        print(l, end=' ')
print()
# 2-4
words.sort()
print(words)

# [문제 3]
files=['intra.h','intra.c','define.h','run.py','ex01.py','intro.hwp']
# 3-1
for p in files:
    p=p.split('.')[0]
    print(p, end=' ')
print()
            
# 3-2
for f in files:
    if f.endswith('.h') or f.endswith('.c'):
        print(f, end=' ')
print()
# 3-3
for th in files:
    if th.count('e')>=2 and 'f' in th:
        print(th, end=' ')
print()

# [문제 4]
def factorial(number):
    mul=1
    for num in range(1,number+1):
        mul=mul*num
    return mul

num=int(input("팩토리얼 숫자 : ").strip())
print(f'{num}! 결과 : {factorial(num)}')

# [문제 5]
for gugudan in range(2,10):
    print(f'---{gugudan}단---')
    for nums in range(1,10):
        print(f'{gugudan} * {nums} = {gugudan*nums}')

# [문제 6]
while True:
    numbers=input("""2개 정수와 사칙연산자를 다음과 같이 입력하세요 (3 4 +) 
종료를 원하시면 다음과 같이 입력하세요 (e n d) : """).strip()
    numbers=numbers.split(' ')
    if numbers[-1]=="+":
        print(f'{numbers[0]} + {numbers[1]} = {int(numbers[0])+int(numbers[1])}')
    elif numbers[-1]=="-":
        print(f'{numbers[0]} - {numbers[1]} = {int(numbers[0])-int(numbers[1])}')
    elif numbers[-1]=="*":
        print(f'{numbers[0]} * {numbers[1]} = {int(numbers[0])*int(numbers[1])}')
    elif numbers[-1]=="/":
        if numbers[1]=='0':
            print("0은 나눌 수 없음")
        else: 
            print(f'{numbers[0]} / {numbers[1]} = {int(numbers[0])/int(numbers[1])}')        
    elif numbers[0]=='e' and numbers[1]=='n' and numbers[2]=='d':
        break