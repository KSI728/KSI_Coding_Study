# 데이터 프레임 생성하기 ( 표 만들기 )

import pandas as pd

# 전역 변수
data=[[17,'남','덕영고'],[15,'여','대구중']]

# 데이터프레임 만들기
#      0    1      2
#  0  17   남  덕영고
#  1  15   여  대구중
data_DF=pd.DataFrame(data)
print(data_DF)

data_DF2=pd.DataFrame(data, index=["김덕영","이대구"],columns=['나이','성별','학교'])
print(data_DF2)