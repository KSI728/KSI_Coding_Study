# [문제 1]
data=[1,5,3,9,1,1,2,8,7,4,2]
data=set(data)
print(type(data))
print(len(data))
print(data)

# [문제 2]
data1=[1,1,5,2,6,9,2]
data2=[5,9,1,3,4,2,8,7,1,2,5]
data3=data1+data2
data3=set(data3)
data3=list(data3)
print(data3)

# [문제 3]
msg='Happy Christmas'.replace(' ','')
msg=set(msg)
print(msg)

# [문제 4]
num6=[1,2,3,4,5,6]
num9=[4,5,6,7,8,9]
print(set(num6)-set(num9))
print(set(num6)&set(num9))
print(set(num6)|set(num9))

# [문제 5]
datas=[9,3,1,8,7,2,1,4,2,3,5,7]
datas=set(datas)
print(sum(datas)/len(datas))   

# [문제 6]
j1=[1,2,3]
j2=[4,5,6,7,8]
j1=j1+j2
print(j1)

# [문제 7]
data4={'name':'pey', 'phone':'0119993323', 'birth':'1118'}
print(data4.get('birth'))
print(data4.get('name'))
print(data4.get('gender','no-data'))

# [문제 8]
# True, False 2가지 데이터만 저장하는 타입은 ( bool )입니다.

# [문제 9]
d1=bool('Happy');print(d1)
d2=bool('');print(d2)
d3=bool([12]);print(d3)
d4=bool([]);print(d4)
d5=bool(('A'));print(d5)
d6=bool(());print(d6)
d7=bool({1:89,2:12});print(d7)
d8=bool({});print(d8)
d9=bool(1);print(d9)
d10=bool(0);print(d10)
d11=bool(None);print(d11)
d12=bool(set());print(d12)

# [문제 10]
stu1=input("학번,이름,전공,학년을 다음과 같이 입력하세요 (21212,아이유,실용음악과,3) : ")
stu2=input("학번,이름,전공,학년을 다음과 같이 입력하세요 (21212,아이유,실용음악과,3) : ")
stu3=input("학번,이름,전공,학년을 다음과 같이 입력하세요 (21212,아이유,실용음악과,3) : ")
stulist={"학생1 정보" : stu1, "학생2 정보" : stu2, "학생3 정보" : stu3}
print(stulist)