# 파일 읽어오기
# 전체 데이터 중 대구광역시 데이터만 불러오기
# 대구광역시 데이터 중 전체 및 9개 구,군별 데이터 불러오기
# 위의 데이터에서 남녀 수 각각 추출하기 
# subplot 활용해서 5X2 형태의 10개 파이 차트 생성하여 시각화

import pandas as pd
import matplotlib.pyplot as plt
import koreanize_matplotlib
import re 

def show_num_pie():
    
    # 파일 읽어오기
    data=pd.read_csv('../D0205/gender.csv',encoding='euc_kr')
    
    # 대구광역시 데이터만 불러오기 
    daegu=data[data['행정구역'].str.contains('대구광역시')]
    
    # 대구광역시 데이터 1열의 (괄호데이터) 삭제
    daegu['행정구역']=[re.split(r'[()]', i)[0] for i in daegu['행정구역']]
    
    # 빈 리스트 지정
    daegu_name_list=[]
    male_count_list=[]
    female_count_list=[]
    
    # 반복문으로 대구 행정구역별 남녀 인구수 출력하기
    for i in range(len(daegu)):
        daegu_name=daegu.iloc[i,0]
        male_count=daegu.iloc[i,105]
        female_count=daegu.iloc[i,208]
        print(f'{daegu_name} : (남:{male_count} 여:{female_count})')
        
        # 빈 리스트에 정보 담기
        daegu_name_list.append(daegu.iloc[i,0])
        male_count_list.append(daegu.iloc[i,105])
        female_count_list.append(daegu.iloc[i,208])
        
    # 딕셔너리로 데이터프레임 만들기
    daegu_df={'name':daegu_name_list,'male':male_count_list,'female':female_count_list}
    df=pd.DataFrame(daegu_df)
    
    # 데이터 정수화
    df['male']=df['male'].str.replace(',','').astype(int)
    df['female']=df['female'].str.replace(',','').astype(int)
    
    # 파이그래프 그리기
    fig, axes = plt.subplots(2, 5, figsize=(15, 6))  # 2행 5열로 서브플롯 생성
    fig.suptitle('대구광역시 구/군별 남녀 인구 비율', fontsize=16)  # 전체 제목
    
    for (i,row), ax in zip(df.iterrows(),axes.flat):
        labels=['남성','여성']
        counts= [row['male'], row['female']]
        ax.pie(counts, labels=labels, autopct='%1.1f%%', startangle=90,counterclock=True)
        ax.set_title(row['name'], fontsize=12)
        
    plt.tight_layout()  # 간격 조정
    plt.show()

show_num_pie()