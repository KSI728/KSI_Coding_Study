from urllib.request	import urlopen
from urllib.request	import Request
from bs4 import BeautifulSoup
import requests

url='http://www.pythonscraping.com/pages/page1.html'
html=requests.get(url)  # 달라진 점 
print('html.encoding:',html.encoding)
print(html.text)  # 해당 URL의 전체 HTML

soup=BeautifulSoup(html.text,'html.parser')
print()
print('h1.string:',soup.h1.string)

# 406 에러 해결법
# headers={'User-Agent':'Mozilla/5.0'} 입력
melon_url='https://www.melon.com/chart/index.htm'

urlrequest=Request(melon_url,headers={'User-Agent':'Mozilla/5.0'})

html=urlopen(urlrequest)
soup=BeautifulSoup(html.read().decode('utf-8'),'html.parser')

# 함수 사용
def use_requests(url):
    response=requests.get(url,headers={'User-Agent':'Mozilla/5.0'})
    soup=BeautifulSoup(response.text,'html.parser')
    print(soup)


def main():
    melon_url='https://www.melon.com/chart/index.htm'
    use_requests(melon_url)
    

main()