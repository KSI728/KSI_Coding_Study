# [문제 1]
score=int(input("점수 입력 : ").strip())

if score==100:
    print("A+")
elif score<100 and score>=95:
    print("A")
elif score<95 and score>=90:
    print("A-")
elif score<90 and score>=85:
    print("B+")
elif score<85 and score>=80:
    print("B")
elif score<80 and score>=75:
    print("B-")
elif score<75 and score>=70:
    print("C+")
elif score<70 and score>=65:
    print("C")
elif score<65 and score>=60:
    print("C-")
elif score<60 and score>=55:
    print("D+")
elif score<55 and score>=50:
    print("D")
elif score<50 and score>=45:
    print("D-")
else:
    print("F")
    
# [문제 2]
score1={'국어':98,'영어':45,'수학':72,'미술':99}
subject=input("국어/영어/수학/미술 중 점수를 확인하고 싶은 과목명 입력 : ")

if subject=='국어':
    print(score1.get('국어'))
elif subject=='영어':
    print(score1.get('영어'))
elif subject=='수학':
    print(score1.get('수학'))
elif subject=='미술':
    print(score1.get('미술'))
else:
    print("존재하는 과목이 아닙니다.")
    
# [문제 3]
data=input("데이터 입력 : ")
have_data=["데이터1", "데이터2"]

if data in have_data:
    for i in range(5):
        print(data)
else:
    have_data.append(data)
    print(have_data)
    
# [문제 4]
watermelon=int(input("수확된 수박 무게 입력 : ").strip())
wlist=[]
wlist.append(watermelon)
wlist1=[];wlist2=[];wlist3=[];wlist4=[]

if watermelon>10:
    grade=[1]
    wlist1.append(dict(zip(wlist,grade)))
elif watermelon<10 and watermelon>=7:
    grade=[2]
    wlist2.append(dict(zip(wlist,grade)))
elif watermelon<7 and watermelon>=4:
    grade=[3]
    wlist3.append(dict(zip(wlist,grade)))
else:
    grade=[4]
    wlist4.append(dict(zip(wlist,grade)))

print(wlist1);print(wlist2);print(wlist3);print(wlist4)

# [문제 5]
age=int(input('나이 입력 : ').strip())

if age in range(6):
    print('영‧유아')
elif age in range(6,13):
    print('아동')
elif age in range(13,19):
    print('청소년')
elif age in range(19,30):
    print('청년')
elif age in range(30,50):
    print('중년')
elif age in range(50,65):
    print('장년')
else:
    print('노년')
    
# [문제 6]
sen=input("문장 하나 입력 : ")

for i in sen:
    if i.isupper():
        i=i.lower()
    elif i.islower():
        i=i.upper()
    print(i,end='')

print()

# [문제 7]
def checking(n):
    if isinstance(n,int):
        print("입력 OK")
    elif isinstance(n,float):
        print("입력 OK")
    else:
        print("숫자 데이터가 아닙니다.")

checking(0.5) #()안에 숫자 입력
checking(-5)

# [문제 8]
g=input("숫자 2개와 사칙연산자를 다음과 같이 입력 (3 4 +) : ").split()

if g[-1]=='+':
    print(f'{g[0]} + {g[1]} = {int(g[0])+int(g[1])}')
if g[-1]=='-':
    print(f'{g[0]} - {g[1]} = {int(g[0])-int(g[1])}')
if g[-1]=='*':
    print(f'{g[0]} * {g[1]} = {int(g[0])*int(g[1])}')
if g[-1]=='/':
    print(f'{g[0]} / {g[1]} = {int(g[0])/int(g[1])}')
    if g[1]=='0':
        print('0으로 나눌 수 없음')

# [문제 9]
message=input('문자 1개 입력(한글은 자음만 인식) : ').strip()

if message.isalpha():
    print(bin(ord(message)))
elif message in ['ㄱ','ㄴ','ㄷ','ㄹ','ㅁ','ㅂ','ㅅ','ㅇ','ㅈ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ']:
    print(bin(ord(message)))


# [문제 10]
def check(n):
    if isinstance(n,int):
        print('정수')
        if n<0:
            print("음수")
        elif n>0:
            print("양수")
        elif n==0:
            print("0")
    elif isinstance(n,float):
        print('실수')

check(0.6) #()안에 숫자 입력    