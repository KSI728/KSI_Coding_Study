import numpy as np

# 동일값 반복
np.tile('A',5)

# 세로 방향 결합
# print(pd.concat([df_1,df_2]))


# 가로 방향 결합
# print(pd.concat([df_1,df_2], axis=1))