# Unit12 
# [연습 문제 1]
camille={"health":575.6,"movement_speed":340,"mana":333.8}
print(camille["health"])
print(camille["movement_speed"])
# [심사 문제 1]
# 표준 입력 : health mana melee attack_speed magic_resistance
#            573.6 308.8 600 0.625 35.7  
data1=input().split()
data2=map(float,(input().split()))
data3=dict(zip(data1,data2))
print(data3)

# Unit13
# [연습 문제 1]
x=5
if x != 10:
    print("ok")
# [심사 문제 1]
first=int(input("가격 입력 : "))
second=input("쿠폰 이름 입력 : ")
if second == "Cash3000":
    print(first-3000)
if second == "Cash5000":
    print(first-5000)

# Unit 14
# [연습 문제 1]
written_test=75
coding_test=True
if written_test >= 80 and coding_test==True:
    print('합격')
else:
    print('불합격')

# [심사 문제 1]
score=input().split()
for num in range(len(score)):
    score[num]=int(score[num])
    
if sum(score)/len(score)>=80:
    print("합격")
else:
    print("불합격")

# Unit15
# [연습 문제 1] 
x=int(input())
if x<=20 and x>=11:
    print("11~20")
elif x<=30 and x>=21:
    print("21~30")
else:
    print("아무것도 해당하지 않음")

# [심사 문제 1]
age=int(input())
balance=9000
if age>=7 and age<=12:
    balance=9000-650
elif age>=13 and age<=18:
    balance=9000-1050
else:
    balance=9000-1250
print(balance)