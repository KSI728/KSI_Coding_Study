import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

df=pd.DataFrame({'english':[60,70,76,80,65,90],
                 'mathematics':[65,76,77,88,69,100]})

# 산점도 그래프 그리기
english_scores=np.array(df['english'])
math_scores=np.array(df['mathematics'])

fig=plt.figure(figsize=(8,8))
ax=fig.add_subplot(111)

ax.scatter(english_scores,math_scores)
ax.set_xlabel('english')
ax.set_ylabel('mathematics')

# 회귀직선 그리기
poly_fit=np.polyfit(english_scores,math_scores,1)

poly_1d=np.poly1d(poly_fit)

xs=np.linspace(english_scores.min(),english_scores.max())

ys=poly_1d(xs)

fig=plt.figure(figsize=(8,8))
ax=fig.add_subplot(111)
ax.plot(xs,ys,color='gray',
        label=f'{poly_fit[1]:2f}+{poly_fit[1]:2f}x')
ax.scatter(english_scores,math_scores,label='score')
plt.show()