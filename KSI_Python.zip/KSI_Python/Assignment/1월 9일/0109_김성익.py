# Unit 16
# [연습 문제 1]
x=[49, -17, 25, 102, 8, 62, 21]
for i in range(len(x)):
    x[i]=x[i]*10
for k in x:
    print(k, end=' ')
print()
    
# [심사 문제 2]
num=int(input().strip())
for nums in range(1,10):
    print(f'{num} * {nums} = {num*nums}')
    
# Unit 19
# [연습 문제 1]
for i in range(5):
    for j in range(5):
        if j >= i:
            print('*',end='')
        else:
            print(' ',end='')    
    print()

# [심사 문제 1]
num=int(input())
for i in range(1, num*2, 2):
    print(('*'*i).center(num*2-1))

# Unit 20
# [연습 문제 1]
for i in range(1,101):
    if i%2==0 and i%11==0:
        print('FizzBuzz')
    elif i%2==0:
        print('Fizz')
    elif i%11==0:
        print('Buzz')
    else:
        print(i)
        
# [심사 문제 1]
num1=int(input().strip())
num2=int(input().strip())
for n in range(num1,num2+1):
    if n%5==0 and n%7==0:
        print('FizzBuzz')
    elif n%5==0:
        print('Fizz')
    elif n%7==0:
        print('Buzz')
    else:
        print(n)