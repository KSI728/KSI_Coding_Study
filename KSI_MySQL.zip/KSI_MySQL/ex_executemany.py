import pymysql

conn=pymysql.connect(host='localhost',user='ksi',password='1234',db='sqlclass_db',charset='utf8')

curs=conn.cursor()

# customer 테이블에 데이터 추가 
sql='''insert into customer(name,category,region)
        values (%s, %s, %s)'''
data=(('홍진우',1,'서울'),
      ('강지수',2,'부산'),
      ('김청진',1,'대구'))

# 여러 개의 tuple 데이터를 처리 
curs.executemany(sql,data)
conn.commit()

print('executemany() 완료')
curs.close()
conn.close()