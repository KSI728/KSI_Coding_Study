from bs4 import BeautifulSoup

html_example = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BeautifulSoup 활용</title>
</head>
<body>
    <h1 id="heading">Heading 1</h1>
    <p>Paragraph</p>
    <span class="red">BeautifulSoup Library Examples!</span>
    <div id="link">
        <a class="external_link" href="www.google.com">google</a>
        <div id="class1">
            <p id="first">class1's first paragraph</p>
            <a class="external_link" href="www.naver.com">naver</a>

            <p id="second">class1's second paragraph</p>
            <a class="internal_link" href="/pages/page1.html">Page1</a>
            <p id="third">class1's third paragraph</p>
        </div>
    </div>
    <div id="text_id2">
        Example page
        <p>g</p>
    </div>
    <h1 id="footer">Footer</h1>
</body>
</html>
'''

# 태그를 사용해서 요소에 직접 접근하기 
from bs4 import BeautifulSoup
soup = BeautifulSoup(html_example, 'html.parser')

print(soup.title)  # <title> 전체를 가져옴
print(soup.title.string)      # 서로
print(soup.title.get_text())  # 동일
print(soup.body)   # <body> 직접 접근 
print(soup.h1)     # h1 태그 접근 
print(soup.h1.string)           

# 해당 태그를 포함하고 있는 부모 
print(soup.title.parent)  # <head>

# <a> 태그 접근 (해당 조건 맨 처음 검색된 결과)
print(soup.a)              # 태그 전체(태그까지 포함)
print(soup.a.string)       # 태그 내부의 텍스트
print(soup.a['href'])      # 태그 내부의 href 속성 url
print(soup.a.get('href'))  # 위와 동일
print(soup.a['class'])     # class는 list 타입으로 반환 

# find() 함수 
# 해당 조건 맨 처음 검색된 결과 출력
div_tag=soup.find('div') # 변수에 저장해서 시간 단축

# div 태그 중 특정 속성을 가지는 항목 추출
# 딕셔너리 형태로 입력 : ,{속성:속성값}
print(soup.find('div',{'id':'text_id2'}))

# a태그 중 class 속성값이 internal link인 정보 추출 
href_link=soup.find('a',{'class':'internal_link'})
print(href_link)

# attrs : 태그 내부의 모든 속성 가져오기
print('href_link.attrs:',href_link.attrs) # 모든 속성 출력 
print('class 속성값: ', href_link['class'])  # class 속성값 : list 형태로 리턴
values=list(href_link.attrs.values())

# href 속성 값이 'www.google.com' 항목 검색
href_value=soup.find(attrs={'href':'www.google.com'})
href_value=soup.find('a',attrs={'href':'www.google.com'})

print(href_value)
print(href_value['href'])
print(href_value.string)

# span 태그 속성 가져오기
span_tag=soup.find('span')
print(span_tag)
print(span_tag.attrs)
print(span_tag.attrs['class'])
print(span_tag.text)
