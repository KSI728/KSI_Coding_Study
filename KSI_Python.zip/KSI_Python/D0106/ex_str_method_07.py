# 메서드(method) : str 타입 전용 함수
# 문법 : 변수명.메서드명()

# [12] join()
# 여러 개 문자열을 특정 문자로 연결해서 1개의 문자열 생성
result='*'.join(['abc','123','???'])
print(result)


