# 제어문 = while 반복문
# 반복 횟수가 미정인 경우에도 사용 가능 
# 반복 횟수가 정해진 경우에도 사용 가능

# 반복 횟수가 정해지지 않은 경우 
# 임의의 숫자 설정 
lucky=7
while True: # 무한히 반복
    num=input("Find me if you can!").strip()
    num=int(num)
    # 반복 중단 조건
    if num==lucky:
        print("WoW")
        break