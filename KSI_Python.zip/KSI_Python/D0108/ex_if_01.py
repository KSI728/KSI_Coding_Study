# 제어문 - 조건문
# 특정 조건에 맞을 때 실행되는 코드와 실행되지 않는 코드 분리 

# [예제] 숫자 2개 입력 받아서 덧셈 결과를 출력하세요.
num1=input("숫자 1개 입력 : ").strip()
num2=input("숫자 1개 입력 : ").strip()

# [1] 입력 데이터 존재 여부 체크 
# (1) 숫자를 입력했다면, 덧셈연산 수행, 
# (2) 입력하지 않았다면, "잘못된 데이터 입력입니다." 문구 출력
if (len(num1)>0 and len(num2)>0): 
    if (num1.isdigit() and num2.isdigit()):
        print(f'{num1}, {num2} 입력 완료')
        print(f'{num1} + {num2} = {int(num1)+int(num2)}')
    else:
        print("숫자 데이터를 입력하세요.")
else:
    print("잘못된 데이터 입력입니다.")
