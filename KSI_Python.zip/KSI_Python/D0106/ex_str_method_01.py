# 메서드(method) : str 타입 전용 함수
# 문법 : 변수명.메서드명()

# [1] index()
# 문자열에서 원소의 인덱스 찾아주는 메서드 
# 찾는 원소가 없을 경우 : not found ERROR
data="Happy 2025"
print(data.index('y'))
print(data.index('2025')) #시작 인덱스만 찾아준다.

# [2] find()
# 문자열에서 원소의 인덱스 찾아주는 메서드 
# index() 메서드와 달리 찾는 원소가 없을 경우 에러를 내지 않고 -1을 나타낸다. 
print(data.find('y'))
print(data.find('b')) #b는 Happy 2025에 속하지 않으므로 -1이 출력된다.

# [응용] 두번째 p의 인덱스 찾기 / 두 세번째 G의 인덱스 찾기 
data="Happy 2025"
print(data.index('p'));print(data.find('p')) #모두 첫 p의 인덱스만 나타낸다.
first=data.index('p')
second=data.index('p',first+1)
print(second)

data2="Good Good Good"
idx=data2.index('G');print(idx)
idx=data2.index('G',idx+1);print(idx)
idx=data2.index('G',idx+1);print(idx)

# [3] rindex(), rfind() 
# 순서를 거꾸로 해서 인덱스를 찾아줌 (reverse)
print(data2.rindex('G')) #맨 뒤에 위치한 G가 출력되었다. 
print(data2.rindex('G',0,-4)) #뒷 범위를 삭제하면서 두번째에 위치한 G가 출력되었다. 