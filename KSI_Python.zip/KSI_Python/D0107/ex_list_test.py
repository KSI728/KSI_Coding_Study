# [실습] 중간고사 점수를 입력 받아서 저장하기 
# - 5과목 점수를 리스트에 저장 
List=[]

score=input("중간고사 점수를 입력하세요 : ").strip()
List.append(int(score))
score=input("중간고사 점수를 입력하세요 : ").strip()
List.append(int(score))
score=input("중간고사 점수를 입력하세요 : ").strip()
List.append(int(score))
score=input("중간고사 점수를 입력하세요 : ").strip()
List.append(int(score))
score=input("중간고사 점수를 입력하세요 : ").strip()
List.append(int(score))

print(List)
print(sum(List))
print(sum(List)/5)

# 새로운 점수 입력 받기 => 기존 점수 삭제 
score.clear()
print(List)