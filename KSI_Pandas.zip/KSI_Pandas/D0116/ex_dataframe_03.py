# 데이터 프레임 속성 읽기 & 변경하기

import pandas as pd

# 전역 변수
data=[[17,'남','덕영고'],[15,'여','대구중']]
data_DF=pd.DataFrame(data)

# 데이터프레임 속성 읽기
print(data_DF.index)  #행 이름
print(data_DF.columns)  #열 이름
print(data_DF.values)  #속한 데이터 값만 출력

# index와 column을 지정한 경우,
data_DF2=pd.DataFrame(data, index=["김덕영","이대구"],columns=['나이','성별','학교'])
print(data_DF2)
print(data_DF2.index)
print(data_DF2.columns)

# 데이터프레임 속성 변경
# (1) column 명 속성을 영어로 변경
data_DF2.columns=['age','gender','school']
print(data_DF2)

# (2) 행 인덱스 속성을 영어로 변경
data_DF2.index=['H01','M01']
print(data_DF2)

# (3) 값 속성 변경은 불가능!
# data_DF2.values=[[17,'남','덕영고'],[15,'여','서울중']] (# 불가능)
# ERROR
