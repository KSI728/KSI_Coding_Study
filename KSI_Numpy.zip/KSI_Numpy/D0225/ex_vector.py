import numpy as np

# 넘파이 이름 출력
print(np.ndarray.__name__)

# 스페셜 메서드는 앞과 뒤에 밑줄 2개가 붙음
# dir() : 객체 속성, 메서드 목록 파악 
# np.ndarray.var : 파이썬 내부에서 작성된 디스크립터의 클래스 객체 
for i in dir(np.ndarray):    
    if not i.startswith("_"):
        if type(np.ndarray.__dict__[i]) != type(np.ndarray.var)  :
            print(i)

# 넘파이 배열 생성하기 

# [1-1] 1차원 배열
# 리스트와 튜플을 넘파이 배열로
list1=[1,2,3,4]
tuple1=(1,2,3,4)

a=np.array(list1)
b=np.array(tuple1)

# 메모리와 값 출력
print(a.data)  #메모리
print(a.data.obj)  # 값을 출력하기 위해선 메모리에 선접근이 필요하다 

# 원소 갱신 
a[0]=100
print(a)

# 타입 바꾸기
e=np.array(a,dtype=np.float64)
print(e)

# [1-2] 2차원 배열
a2 = np.array([[1,2,3],[4,5,6]])
print(a2.shape) 
print(a2.ndim)  
print(a2.shape) 
print(a2.size)  # 갯수 세기 

# [1-3] 벡터화 연산 
a=np.arange(6,10)
b=np.arange(2,6)
c=a*b  # 서로서로 곱함 
print(c)

# [1-4] 축 연산 
a2=np.array([1,2,3,4])

# .reshape(행,열)
a2=a2.reshape(2,2)  

print(np.sum(a2,axis=0))

