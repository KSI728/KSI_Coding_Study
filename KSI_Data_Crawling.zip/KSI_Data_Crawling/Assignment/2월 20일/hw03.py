from bs4 import BeautifulSoup
import pandas as pd
import	requests  # 한글 깨짐 문제 해결


url=f'https://finance.naver.com/sise/sise_market_sum.naver'
html=requests.get(url)
soup=BeautifulSoup(html.text,'html.parser')

url_list1=[]  # url
name_list1=[]  # 이름

tbody=soup.find('tbody')

for ju in tbody.find_all('tr'):
    ju_td = ju.find_all('td')
    
    for a in ju_td:
        a_data=a.find_all('a',{'class':'tltle'})
        
        for i in a_data:
            url_list1.append(i['href'])
            name_list1.append(i.string)
            
url_list2=url_list1[:10]
url_list2=['https://finance.naver.com'+item for item in url_list2]  # 최종 url list
name_list2=name_list1[:10]  # 최종 회사명 list

now_list=[]  # 현재가
pre_list=[]  # 전일가
si_list=[]  # 시가
high_list=[]  # 고가
low_list=[]  # 저가

now_list2=[]  # 현재가 최종
pre_list2=[]  # 전일가 최종
si_list2=[]  # 시가 최종
high_list2=[]  # 고가 최종
low_list2=[]  # 저가 최종

for url in url_list2:
    new_url=url
    html1=requests.get(url)
    soup1=BeautifulSoup(html1.text,'html.parser')
    
    div=soup1.find('div',{'class','content_wrap'})
    if div:
        span=div.find_all('span',{'class':'blind'})
        span_texts = [span.text for span.text in span]
        
        for nums in span:
            now_list.append(span_texts[0].string)
            pre_list.append(span_texts[3].string)
            si_list.append(span_texts[4].string)
            high_list.append(span_texts[7].string)
            low_list.append(span_texts[8].string)
            
for i in range(0, len(now_list), 10):
    now_list2.append(now_list[i])

for i in range(0, len(pre_list), 10):
    pre_list2.append(pre_list[i])
    
for i in range(0, len(si_list), 10):
    si_list2.append(si_list[i])

for i in range(0, len(high_list), 10):
    high_list2.append(high_list[i])
    
for i in range(0, len(low_list), 10):
    low_list2.append(low_list[i])
    
# 종목코드 리스트 생성
code_list = [item[-6:] for item in url_list1]
code_list=code_list[:10]

# 데이터프레임 생성
company_df=pd.DataFrame({'종목명':name_list2,'종목코드':code_list,'현재가':now_list2,'전일가':pre_list2,'시가':si_list2,'고가':high_list2,'저가':low_list2})
print(company_df)

# 프로그램 생성
def find_ju():
    
    while True:
        print('-'*80)
        print('[ 네이버 코스피 상위 10대 기업 목록 ]')
        print('-'*80)
        for i, names in enumerate(company_df['종목명']):
            print(f'[{i+1}] {names}')
            if i == 9:
                break
        
        finding=int(input('주가를 검색할 기업의 번호를 입력하세요(-1:종료) : '))
        
        if finding==1:
            print(f'종목명:{company_df.iloc[0,0]}')
            print(f'종목코드:{company_df.iloc[0,1]}')
            print(f'현재가:{company_df.iloc[0,2]}')
            print(f'전일가:{company_df.iloc[0,3]}')
            print(f'시가:{company_df.iloc[0,4]}')
            print(f'고가:{company_df.iloc[0,5]}')
            print(f'저가:{company_df.iloc[0,6]}')
        
        if finding==2:
            print(f'종목명:{company_df.iloc[1,0]}')
            print(f'종목코드:{company_df.iloc[1,1]}')
            print(f'현재가:{company_df.iloc[1,2]}')
            print(f'전일가:{company_df.iloc[1,3]}')
            print(f'시가:{company_df.iloc[1,4]}')
            print(f'고가:{company_df.iloc[1,5]}')
            print(f'저가:{company_df.iloc[1,6]}')
            
        if finding==3:
            print(f'종목명:{company_df.iloc[2,0]}')
            print(f'종목코드:{company_df.iloc[2,1]}')
            print(f'현재가:{company_df.iloc[2,2]}')
            print(f'전일가:{company_df.iloc[2,3]}')
            print(f'시가:{company_df.iloc[2,4]}')
            print(f'고가:{company_df.iloc[2,5]}')
            print(f'저가:{company_df.iloc[2,6]}')
            
        if finding==4:
            print(f'종목명:{company_df.iloc[3,0]}')
            print(f'종목코드:{company_df.iloc[3,1]}')
            print(f'현재가:{company_df.iloc[3,2]}')
            print(f'전일가:{company_df.iloc[3,3]}')
            print(f'시가:{company_df.iloc[3,4]}')
            print(f'고가:{company_df.iloc[3,5]}')
            print(f'저가:{company_df.iloc[3,6]}')
            
        if finding==5:
            print(f'종목명:{company_df.iloc[4,0]}')
            print(f'종목코드:{company_df.iloc[4,1]}')
            print(f'현재가:{company_df.iloc[4,2]}')
            print(f'전일가:{company_df.iloc[4,3]}')
            print(f'시가:{company_df.iloc[4,4]}')
            print(f'고가:{company_df.iloc[4,5]}')
            print(f'저가:{company_df.iloc[4,6]}')
            
        if finding==6:
            print(f'종목명:{company_df.iloc[5,0]}')
            print(f'종목코드:{company_df.iloc[5,1]}')
            print(f'현재가:{company_df.iloc[5,2]}')
            print(f'전일가:{company_df.iloc[5,3]}')
            print(f'시가:{company_df.iloc[5,4]}')
            print(f'고가:{company_df.iloc[5,5]}')
            print(f'저가:{company_df.iloc[5,6]}')
        
        if finding==7:
            print(f'종목명:{company_df.iloc[6,0]}')
            print(f'종목코드:{company_df.iloc[6,1]}')
            print(f'현재가:{company_df.iloc[6,2]}')
            print(f'전일가:{company_df.iloc[6,3]}')
            print(f'시가:{company_df.iloc[6,4]}')
            print(f'고가:{company_df.iloc[6,5]}')
            print(f'저가:{company_df.iloc[6,6]}')

        if finding==8:
            print(f'종목명:{company_df.iloc[7,0]}')
            print(f'종목코드:{company_df.iloc[7,1]}')
            print(f'현재가:{company_df.iloc[7,2]}')
            print(f'전일가:{company_df.iloc[7,3]}')
            print(f'시가:{company_df.iloc[7,4]}')
            print(f'고가:{company_df.iloc[7,5]}')
            print(f'저가:{company_df.iloc[7,6]}')

        if finding==9:
            print(f'종목명:{company_df.iloc[8,0]}')
            print(f'종목코드:{company_df.iloc[8,1]}')
            print(f'현재가:{company_df.iloc[8,2]}')
            print(f'전일가:{company_df.iloc[8,3]}')
            print(f'시가:{company_df.iloc[8,4]}')
            print(f'고가:{company_df.iloc[8,5]}')
            print(f'저가:{company_df.iloc[8,6]}')

        if finding==10:
            print(f'종목명:{company_df.iloc[9,0]}')
            print(f'종목코드:{company_df.iloc[9,1]}')
            print(f'현재가:{company_df.iloc[9,2]}')
            print(f'전일가:{company_df.iloc[9,3]}')
            print(f'시가:{company_df.iloc[9,4]}')
            print(f'고가:{company_df.iloc[9,5]}')
            print(f'저가:{company_df.iloc[9,6]}')
        
        elif finding==-1:
            break
        
        elif finding not in range(1, 11):
            print('잘못된 번호를 입력하였습니다. 다시 입력하세요.')
                
find_ju()