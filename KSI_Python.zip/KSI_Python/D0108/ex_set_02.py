# set 자료형
# 중복 데이터 저장 불가
# 순서가 없음

data1=set(range(3,101,3))
data2=set(range(5,101,5))
print(data1)

# [1] .union() / | (or 연산자) (shift+원화)
# 2개의 집합에 모든 원소를 합치기 = 합집합 출력
plus=data1.union(data2)
print(plus)
print(f'합집합 : {data1 | data2}')

# [2] .intersection() / & (and 연산자)
# 2개의 집합에 공통된 원소를 추출 = 교집합 출력
minus=data1.intersection(data2)
print(minus)
print(f'교집합 : {data1 & data2}')

# [3] .difference() / - (빼기 연산자)
# 1개 집합에만 존재하는 원소를 추출 = 차집합 출력
result1=data1.difference(data2)
result2=data2.difference(data1)
print(result1)
print(result1)
print(f'차집합 : {data1 - data2}')
print(f'차집합 : {data2 - data1}')