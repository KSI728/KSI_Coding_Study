from urllib.request	import urlopen
from urllib.request	import Request
from urllib.parse import quote
from bs4 import BeautifulSoup
import requests

query=quote(f'대구+날씨')
url='https://search.naver.com/search.naver?query='+query
html=urlopen(url)
soup=BeautifulSoup(html.read(),'html.parser')

# 2
city_address=soup.find('div',{'class':'title_area _area_panel'})
city=city_address.find('h2',{'class':'title'}).text
current_location=city_address.find('span',{'class':'select_txt_sub'}).text

print(f'{city}: {current_location[:-3]}')

# 3 
weather_info=soup.find('div',{'class':'weather_info'})
temperature_text=soup.find('div',{'class':'temperature_text'}).text
weather_stat=soup.find('span',{'class':'weather before_slash'}).text
air=weather_info.select('li.item_today.level2')
sun=weather_info.select_one('li.item_today.type_sun').text

print(f'현재 온도: {temperature_text}')
print(f'날씨 상태 : {weather_stat}')
print("공기 상태:")
for i in air:
    print(i.text.strip())
print(sun.strip())
print('----------------------------------------')

# 4 
tempdata=soup.select('li._li')
print('시간대별 날씨 및 온도')
print('----------------------------------------')
for i in tempdata:
    print(i.text.strip())