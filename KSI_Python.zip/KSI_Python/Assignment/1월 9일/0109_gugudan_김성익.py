# for ~ in 반복문

# 구구단 출력하기 (2단 ~ 9단)
for dan in range(2,10):
    print(f'---{dan}단---',end='\t')
print()
    
for num in range(1,10):
    for dan in range(2,10):
        print(f'{dan} * {num} = {dan*num}',end='\t')
    print()   
        


    