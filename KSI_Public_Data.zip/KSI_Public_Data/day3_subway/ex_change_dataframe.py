import pandas as pd
import numpy as np

df=pd.DataFrame([[1,2],[3,4],[5,6]],columns=['A','B'])

# apply

# [1] 일반 함수 적용 
def plus_one(x):
    x=x+1
    return x

# 열마다 적용
df['A']=df['A'].apply(plus_one)
df['B']=df['B'].apply(plus_one)
print(df)

# 전체 한번에 적용
df=df.apply(plus_one)

# [2] 람다 함수 적용 

# 컬럼 A에 적용
df['A']=df['A'].apply(lambda x:x+1)
print(df)

# 전체 한번에 적용
df=df.apply(lambda x:x+1)
print(df)