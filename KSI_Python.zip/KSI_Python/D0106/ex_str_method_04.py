# 메서드(method) : str 타입 전용 함수
# 문법 : 변수명.메서드명()

# [8] isupper(), islower(), ...
# 알파벳과 관련된 메서드들 (대문자, 소문자 확인 등등)

# (1) isupper()
# 모든 문자가 대문자인지 여부 확인

# (2) islower()
# 모든 문자가 소문자인지 여부 확인 

# (3) istitle()
# 첫 글자가 대문자, 나머지 소문자인지 여부 확인(제목 형식인가가) 
data="Happy New Year"
print(data.istitle()) #Happy New Year 각각 대문자로 시작되고, 뒤는 소문자 이므로 True

# (4) isspace()
# 공백체크 여부 (whitespace)
key="  "
key2="space "
print(key.isspace())
print(key2.isspace()) #whitespace로만 구성이 되어있어야 True