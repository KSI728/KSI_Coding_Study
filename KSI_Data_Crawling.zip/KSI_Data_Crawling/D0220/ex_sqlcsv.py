import pymysql

conn=pymysql.connect(host='localhost',
                     user='ksi',password='1234',db='scraping',charset='utf8')

cur=conn.cursor()
cur.execute('use scraping') # 불러온 db 사용하는 것도 실행

query='''
select * from pages
where id=2
'''
cur.execute(query)

print(cur.fetchone())
cur.close()
conn.close()