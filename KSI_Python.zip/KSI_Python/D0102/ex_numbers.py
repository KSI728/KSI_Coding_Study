# 숫자의 다양한 표현법
'''
2진수 : 0b0
8진수 : 0o0
10진수 : 0
16진수 : 0x0
'''

# 다양한 변환 방법
'''
2진수 : bin(숫자)
8진수 : oct(숫자)
10진수 : int(숫자)
16진수 : hex(숫자)
'''

# 사람 문자 <==> 컴퓨터 / 기계 문자
# 사람 문자 --> 기계어 : 인코딩(Encoding) 
# 사람 문자 <-- 기계어 : 디코딩(Decoding) 

# 사람 문자를 기계어로 변환시켜 주는 내장함수 
# 문법 : ord(문자 1개)
# 예시) Hello를 기계어로 표현하기
print(bin(ord('H'))),print(bin(ord('e'))),print(bin(ord('l'))),print(bin(ord('l'))),print(bin(ord('o')))