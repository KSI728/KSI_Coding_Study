# for ~ in 반복문
# 반복 횟수가 정해진 경우 거의 사용됨
# 여러 개의 원소/요소를 가지는 데이터 타입의 경우 원소/요소 추출에 사용됨
# 문법 : for 변수명 in 데이터 <= 여러 개의 데이터 저장 타입

# [1] str 타입과 반복문 
msg="Merry"
print(f'[0번 요소] {msg[0]}')
print(f'[1번 요소] {msg[1]}')
print(f'[2번 요소] {msg[2]}')
print(f'[3번 요소] {msg[3]}')
print(f'[4번 요소] {msg[4]}')

for char in msg:
    print(char)

# 코드값 반복 출력 
for char in msg:
    print(ord(char))
    
# 기계어로 변경 후 반복 출력
for char in msg:
    print(bin(ord(char))[2:]) #앞에 0b 생략된 채 출력 
    
# 숫자 str 데이터로 구성된 msg
msg='1 3 5 7 9 11 22'
msglist=msg.split()
print(msglist)

# 리스트의 모든 원소를 int로 형변환 => int(원소값)
# 원소값 변경이 되어야 하는 경우에는 인덱스를 반복문으로 추출
for index in range(len(msglist)):
    msglist[index]=int(msglist[index])
print(msglist)




# # [예시] 원소 단위 형변환
# # 데이터를 str => 숫자로 형변환
# numList=['1','5','6']
# numList[0]=int(numList[0])
# numList[1]=int(numList[1])
# numList[2]=int(numList[2]) #반복이 힘들어 => 반복문

# for index in range(5):
#     print(index)

# datalist=['happy','cat',False,56]
# for data in datalist:
#     print(data)
