from urllib.request	import urlopen
from bs4 import	BeautifulSoup
import random
import pymysql
import re


def store(conn, cur, title, content):
    cur.execute('INSERT INTO pages (title, content) VALUES ("%s", "%s")', (title, content))
    conn.commit()  # 수정사항 있으면 무조건 커밋하기 


def get_links(conn, cur, articleUrl):
    html = urlopen('http://en.wikipedia.org' + articleUrl)
    bs = BeautifulSoup(html, 'html.parser')
    title = bs.find('h1').text
    content = bs.find('div', {'id': 'mw-content-text'}).find('p').text
    print(title, content)
    
    # 해당 url에서 find()로 검색된 데이터(<h1>, <p>)를 데이터베이스에 저장
    store(conn, cur, title, content)
    
    # 해당 url에서 모든 <a> 태그를 리스트에 저장 후 리턴
    bodyContent = bs.find('div', {'id': 'bodyContent'})
    wikiUrls = bodyContent.find_all('a', href=re.compile('^(/wiki/)((?!:).)*$'))
    return wikiUrls


def main():
    conn = pymysql.connect(host='localhost',
                           user='ksi', passwd='1234', db='scraping', charset='utf8')
    cur = conn.cursor()
    # 랜덤 시드 (seed에 숫자를 지정하면 그 숫자만 나옴)
    random.seed(None)
    
    # 시작 URL
    links = get_links(conn, cur, '/wiki/Kevin_Bacon')
    
    try:
        while len(links) > 0:
            # 대괄호 안은 리스트가 아니라 인덱스를 의미
            newArticle = links[random.randint(0, len(links)-1)].attrs['href']
            print(newArticle)
            links = get_links(conn, cur, newArticle)
    finally:
        cur.close()
        conn.close()

main()
