import matplotlib.pyplot as plt

y_value=[10,50,20,10]
x_value=[1,3,5,7]
size=[]

for y in y_value:
    size.append(y*5)


# c=range(색상 개수)
# cmap : 컬러맵 속성 사용 jet = 무지개
plt.scatter(x_value,y_value,s=size,c=range(4),cmap='jet')
plt.colorbar()
plt.show()