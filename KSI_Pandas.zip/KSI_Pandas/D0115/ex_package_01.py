# Package(패키지)
# 동일 카테고리에 여러 개의 모듈을 묶어 둔 것
# 문법 : 패키지명.모듈명
# 사용 : import 패키지명.모듈명

# 모듈 로딩
import urllib
import urllib.request as request
request.urlretrieve("https://www.google.co.kr/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png",'logo.png')