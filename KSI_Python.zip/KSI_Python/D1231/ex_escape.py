# 이스케이프 문자 : 특별한 의미를 가지는 문자
# 문법 : \+문자 하나
'''
'\n' : new line을 의미, 즉 엔터키
'\t' : tab키
'\\' : 파일이나 폴더의 경로 나타낼 때 사용
'\'' : 인용부호 홑따옴표 의미
'\"' : 인용부호 쌍따옴표 의미
'''

# [1] '\n' 이스케이프 문자
msg1="happy\nhappy\nhappy"
print(msg1)

# [2] '\t' 이스케이프 문자
msg2="happy\thappy\thappy"
print(msg2)

# [3] '\'' 이스케이프 문자
msg3="happy\'happy\'happy"
print(msg3)


# [4] '\\' 이스케이프 문자
path="C:\\Users\\knudc\\anaconda3"
print(path)

# [5] raw string의 r'  ', R"   ", ...
# 문자열 안의 이스케이프 문자를 무시해주는 기능
path1=r'C:\Users\knudc\anaconda3'
code1=r"happy\'happy\'happy"
print(code1)

# end=''
# 끝에 ''속에 들어있는 정보를 저장함
print("cat", end='')
print("dog") 

# sep=''
# 값과 값 사이에 정보나 문자를 넣을 때 사용함
print("cat", "dog", sep='')