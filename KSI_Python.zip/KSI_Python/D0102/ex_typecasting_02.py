# 내장함수                          

# 데이터 타입 / 종류를 변경해주는 내장함수
# 타입 캐스팅 Type Casting / 형변환

# [2] float()
print(float(-8))   # 음수 int를 float으로 변환
print(float(0.123))  # 소수 int를 float으로 변환
print(float(int("0b11100", base=2))) # str을 2진수로 float으로 변환
print(float(False)) # bool을 float으로 변환

# [3] bool()
print(bool(0))  # 0을 bool로 변환
print(bool(0.001)) # 0 또는 0.000 이 아닌 모든 숫자는 True로 변환됨
print(bool(0.000)) # 0.000 형태이기 때문에 0
print(bool('abc'))  # 뭐라도 적혀있음 -> True
print(bool(''))  # empty string 빈문자열 -> 0 -> False
print(bool(' '))  # white string 공백문자열 -> 1 -> True