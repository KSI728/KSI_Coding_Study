# comprehension
# for ~ in + if + List/Set/Dict 결합한 문법
# 시간과 메모리 상의 이득으로 아주 많이 사용됨!

# str 타입 숫자를 여러 개 저장한 List 
# int 타입 숫자로 변환한 새로운 List 만들기
data1=['11','22','33']
data2=[]
for num in data1:
    data2.append(int(num))

print(data1, data2, sep='\n')

# []와 for 결합
data3=[int(num) for num in data1]
print(data3)

#----------------------------------------------------
# 숫자 데이터를 저장하고 있는 List에서 2의 배수인 숫자만 새로운 List의 원소로 넣기
# 새로운 List에 원소로 넣기
data1=[3,4,5,6,7,8,9]
data2=[]
for num in data1:
    if not num%2:
        data2.append(num)
print(data2)

# []와 for와 if 결합
data3=[ num for num in data1 if not num%2 ]
#           ------(1)-------        
#                    ------> -----(2)-----
#      -(3)-         <------  True 일 때,
print(data3)

#----------------------------------------------------
# 숫자 데이터를 저장하고 있는 List에서 2의 배수인 숫자는 제곱해서 전달하고, 
# 2의 배수가 아닌 숫자는 그대로 전달해서 새로운 List에 원소로 넣기
data1=[3,4,5,6,7,8,9]
data2=[]
for num in data1:
    if not num%2:
        data2.append(num**num)
    else:
        data2.append(num)
print(data2)

# []와 for와 if 결합
data3=[ num**num if not num%2 else num for num in data1 ]
#                                      ------(1)-------        
#       --------------(2)----------num <------
print(data3)