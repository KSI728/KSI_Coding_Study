from urllib.request	import urlopen
from bs4 import BeautifulSoup
import pandas as pd

# 빈 list 생성
store_list=[]      # 화면 출력용
store_csv_list=[]  # csv 변환용

# 중복 체크용 빈 set 생성
store_set=set() 

# 반복문으로 페이지 한번에 출력
store_count=1
for i in range(1,49):
    url=f'https://www.hollys.co.kr/store/korea/korStore2.do?pageNo={i}&sido=&gugun=&store='
    html=urlopen(url)
    soup=BeautifulSoup(html.read(),'html.parser')

    tbody=soup.find('tbody')
    tr=tbody.find_all('tr')
    
    for k in tr:
        td=k.find_all('td')
        
        if len(td)>5:
            name=td[1].text.strip()
            region=td[0].text.strip()
            address=td[3].text.strip()
            phone=td[5].text.strip()

            store_key = (name,address,phone)
                
            if store_key not in store_set:
                store_list.append(f"[{store_count}]: 매장이름: {name}, 지역: {region}, 주소: {address}, 전화번호: {phone}")
                store_csv_list.append([name, region, address, phone])
                store_set.add(store_key)
                store_count += 1

# 크롤링 결과 출력         
for store in store_list:
    print(store)    
    
# 전체 매장 수 출력
print(f'전체 매장 수: {store_count-1}')

# csv 파일로 저장하기     
df=pd.DataFrame(store_csv_list, columns=['매장이름','지역','주소','전화번호'])
df.to_csv('hollys_branches.csv', index=False, encoding='utf-8-sig', quoting=1)
        
print('hollys_branches.csv 파일 저장 완료')
