# 모듈 내의 특정 변수, 함수, 클래스 불러오기
# 주의점 : 파일 내에 동일한 변수, 함수, 클래스 존재 시 모듈의 변수, 함수, 클래스는 무시됨
# 사용법 
# from 모듈명 import 변수, 함수, 클래스 (특정 가져오기)
# from 모듈명 import * (모두 가져오기)

# 수학 모듈에서 factorial 함수만 가져오기
from math import factorial, pi
from math import *

# 전역 변수 선언
pi='삼일사'

# 사용자 정의 함수
def factorial(x):
    print('my factorial()')
    for num in (x,0):
        print(num, 'x')

# 지정된 함수를 바로 사용 => 모듈명 X
print('4!', factorial(4))
