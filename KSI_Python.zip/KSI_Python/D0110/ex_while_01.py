# 제어문 = while 반복문
# 반복 횟수가 미정인 경우에도 사용 가능 
# 반복 횟수가 정해진 경우에도 사용 가능

# [예제] 반복 횟수가 정해진 경우 while 반복문
# Down-counting : 10,9,8,7,...,1

# 방법 1 : for ~ in
for num in range(10,0,-1):
    print(num, end=' ')
print()

# 방법 2 : while 
count=10
while count>0:  #10>0 while True:
    print(count,end=' ')
    count=count-1  #count=count-1도 반복되면서 결국 0>0까지 도달
print()
    
# 구구단 9단을 while문으로 출력
number=1
while number<10:
    print(f'9 * {number} = {9*number}')
    number=number+1
        