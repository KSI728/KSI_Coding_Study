# str 타입과 멤버연산자
# 문법 : 왼쪽 in 오른쪽 
# 기능 : 왼쪽 데이터가 오른쪽 데이터 안에 존재하는지 여부 => 결과 : True/False

print('P' in "Python") 
print('p' in "Python") #소문자 p와 대문자 P는 서로 다르므로 False가 출력된다.
print(' P' in " Python") 

# 문법 : 왼쪽 not in 오른쪽 
# 기능 : 왼쪽 데이터가 오른쪽 데이터 안에 존재하지 않는지 여부 => 결과 : True/False
print('P' not in "Python") #없어야 True

# [실습] 주민번호 7번째 자리의 숫자를 확인해서 남자인지 여부 출력 
# 남자 : 1, 3, 5, 7
# 여자 : 2, 4, 6, 8
code=input("주민번호를 입력하시오 : ")
print(f"입력한 바에 따라 성별이 남자인지 여부 확인 : {code[7] in '1357'}") #더욱 간단