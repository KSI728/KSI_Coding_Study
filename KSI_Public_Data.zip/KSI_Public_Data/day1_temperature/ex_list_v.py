import csv
import matplotlib.pyplot as plt

f=open('data/daegu.csv',encoding='utf-8-sig') 
data=csv.reader(f)

header=next(data)
result=[]  # 빈 리스트 생성

for row in data:
    if row[4]!='':
        result.append(float(row[4]))
        
print(len(result))
f.close()

plt.figure(figsize=(10,2))
plt.plot(result,'r')
plt.show()