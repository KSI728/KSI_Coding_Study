import pandas as pd
from tabulate import tabulate  # 예쁘게 출력하는 모듈

coffeeshop_df=pd.read_csv('hollys_branches.csv',encoding='utf-8-sig', quotechar='"')


def find_coffeeshop():
    
    while True:
        finding=input('검색할 매장의 지역을 입력하세요 : ')
        
        if finding=='quit':
            print('종료 합니다.')
            break
        
        # 입력한게 있으면 출력       
        for_print=coffeeshop_df[coffeeshop_df['지역'].str.contains(finding)]
        print(f'검색된 매장 수: {len(for_print)}')
        print(tabulate(for_print.drop(columns=['지역']), headers='keys', tablefmt='pretty', stralign='left'))

find_coffeeshop()