package java_practice;

public class Member {
	public int id;
	public String name;
	
	// 오버로딩
	public Member(String name) {
	this.id = 0;
	this.name = name;
	}
	
	// 오버로딩2
	public Member(int id, String name) {
	this.id = id;
	this.name = name;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Member target) {
			if(name.equals(target.name) &&
				id == target.id) {
				return true;
			}
		}
		return false;
	}
}