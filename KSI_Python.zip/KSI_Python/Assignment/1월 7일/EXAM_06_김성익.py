# [문제 1]
# 1-1
list1=[10,40,"홍길동",False,40,False]
# 1-2
print(list1[3],list1[-1],type(list1[3]),type(list1[5]))
# 1-3
nums=[1,6,3,9,10]
datas=['a','b','f','z']
print(nums+datas)
# 1-4
print(nums*10)
# 1-5
print(nums[::-1])
print(nums[::3])
print(nums[::2])

# [문제 2]
nums=[]
nums.append(10)
nums.append(3)
nums.append(91)
print(nums) #[10, 3, 91]
nums.remove(3) #[10, 91]
# nums.remove(100) #ERROR
nums.insert(1,24) #[10, 24, 91]

# [문제 5]
nums=[1,2,3,1,2,3,5,6,7,3]
print(len(nums))
print(nums.count(3))
print(nums.index(6))
del nums[-1]
del nums[2]

# [문제 4]
nums=[1,2,3,1,2,3]
data=['a','c']
print(nums+data)

# [문제 5]
data=['a','c',True, 1, 9, 23, 'Happy', 21]
data.remove(21)
data.remove(23);data[1]='b'
data.insert(1,2022)

# [문제 1-10]
datas=[9,30,1,21,5,8,0]
datas.sort()
print(datas)
datas.sort(reverse=True)
print(datas)

#------------------------------------------

# [튜플 문제]
# 2-1
'''
여러 데이터를 저장할 수 있으며, 인덱싱과 슬라이싱이 가능함.
하지만 한번 저장하면 수정, 추가, 삭제 등이 일체 불가함.
( ) 사용, 그러나 ( ) 생략 가능.
요소 1개 입력시 반드시 뒤에 ,를 붙여야 함.
'''
# 2-2
non=(10,30,89,10,23,1,2,7,11)
# 2-3
print(non[0],non[1],non[2],non[3],non[4],non[5],non[6],non[7],non[8])
print(non[::2])
print(non[3::3])
# 2-4
# 괄호가 없이 info 변수 안에 여러 데이터가 저장 => Tuple
# Tuple은 수정이 불가능하기 때문에 에러 발생
# 2-5
year=2022,
datas=(False,100,19.8,'Good')

#-----------------------------------------
# [종합 문제]
# 3-1
# 2000년 생 이후 한정, 만 나이 계산 불가
code=input("주민번호를 다음과 같이 입력(000000-0000000) : ")
print(f'20{code[:2]}년 {int(code[2:4])}월 {int(code[4:6])}일 생 {25-int(code[:2])+1}세')
# 3-2
data=list(range(1,51))
print(data[2::3])
print(data[7::8])
print(max(data))
print(min(data))
print(sum(data))
print(sum(data)/len(data))