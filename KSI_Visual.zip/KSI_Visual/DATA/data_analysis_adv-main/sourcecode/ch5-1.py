import pandas as pd
import streamlit as st

df = pd.read_csv('./datasets/CO2_emissions/CO2_emissions.csv')
df