# Unit 17
# [연습 문제 1]
i=2
j=5
while i<=32 and j>=1:
    print(i,j)
    i=i*2
    j=j-1

# [심사 문제 1]
cost=int(input().strip())
while cost>=1350:
    cost-=1350
    print(cost)

# Unit 29  
# [연습 문제 1]
x=10
y=3
def get_quotient_remainder(a,b):
    return a//b, a%b
quotient, remainder = get_quotient_remainder(x,y)
print('몫: {0}, 나머지: {1}'.format(quotient,remainder))

# [심사 문제 1]
x,y=map(int,input().split())
def calc(one,two):
    a=one+two
    b=one-two
    c=one*two
    d=one/two
    return a,b,c,d
    
a,s,m,d=calc(x,y)
print('덧셈: {0}, 뺄셈: {1}, 곱셉: {2}, 나눗셈: {3}'.format(a,s,m,d))

# Unit 18
# [연습 문제 1]
i=0
while True:
    if i%10!=3:
        i+=1
        continue
    if i>73:
        break # if 자체가 영향을 받는 것이 아니라, while문이 break 된다. 
    print(i,end=' ')
    i+=1
print()

# [심사 문제 1]
# 3으로 끝나면 안됨
start, stop = map(int, input().split())
i=start
while True:
    if i%10==3:
        i+=1
        continue
    if i>stop:
        break    
    print(i,end=' ')
    i+=1