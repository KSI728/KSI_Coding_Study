# [문제 1]
jumsu={'국어':98,'음악':71,'미술':90,'체육':82,'과학':88}
jumsu2=list(jumsu.values())
print(sum(jumsu2))
print(sum(jumsu2)/len(jumsu2))

# [문제 2]
data={"김연아":"피겨스케이팅", "류현진":"야구", "박지성":"축구", "귀도":"파이썬"}
print(data.keys())
print(data.values())
print(data.items())

# [문제 3] #다시 살펴볼 것!
person=[]
person_keys=['이름', '전화번호']
data=input('이름과 전화번호를 다음과 같이 입력하세요(이름,전화번호) : ').strip().split(',')
person.append(dict(zip(person_keys, data)))

data=input('이름과 전화번호를 다음과 같이 입력하세요(이름,전화번호) : ').strip().split(',')
person.append(dict(zip(person_keys, data)))

data=input('이름과 전화번호를 다음과 같이 입력하세요(이름,전화번호) : ').strip().split(',')
person.append(dict(zip(person_keys, data)))
print(person)

# [문제 4]
foods={'한식':'불고기','중식':'자장면','일식':'스시'}
print(foods.get('한식'))
print(foods.get('일식'))

# [문제 5]
foods={'한식':'불고기','중식':'자장면','일식':'스시'}
like=input("좋아하는 한식 입력 : ").strip()
foods['한식']=like
like1=input("좋아하는 중식 입력 : ").strip()
foods['중식']=like1
like2=input("좋아하는 일식 입력 : ").strip()
foods['일식']=like2
print(foods)

# [문제 6]
datas={"류현진":"야구", "김연아":"피겨스케이팅", "박지성":"축구", "귀도":"파이썬"}
datas["손흥민"]="축구"
datas=sorted(datas)
print(datas)

# [문제 7]
d1=[]
d2=()
d3={}
d4=set()
d5=''

# [문제 8]
student={'name':['베트맨','마징가','슈퍼맨','슈렉','피오나'],'kor':[90,82,77,94,78],'math':[89,71,100,82,99],'eth':[98,80,92,93,91],'his':[99,91,90,71,83]}
print(f"국어 최고 점수 : {max(student['kor'])} 국어 최저 점수 : {min(student['kor'])}")
print(f"수학 최고 점수 : {max(student['math'])} 수학 최저 점수 : {min(student['math'])}")
print(f"윤리 최고 점수 : {max(student['eth'])} 윤리 최저 점수 : {min(student['eth'])}")
print(f"국사 최고 점수 : {max(student['his'])} 국사 최저 점수 : {min(student['his'])}")

# [문제 9]
msg="Good Luck"
msg=msg.replace(' ','')
msg=msg.upper()
msg=list(msg)
print(msg)

# [문제 10]
list1=list(range(2,50,2))
list2=list(range(5,50,5))
list3=list(range(7,50,7))
list4=set(list1+list2+list3)
list4=list(list4)
print(list4)