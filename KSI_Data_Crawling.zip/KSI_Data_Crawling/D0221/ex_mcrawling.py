from selenium import webdriver
from selenium.webdriver.common.by import By
import time 

driver=webdriver.Chrome()
driver.get("https://www.selenium.dev/selenium/web/web-form.html")

print(f'title:{driver.title}')
print(driver.page_source)  # 모든 HTML 가져옴
time.sleep(10)   


#----------------------------------------------------------------
driver.get('http://www.pythonscraping.com/pages/warandpeace.html')
driver.implicitly_wait(5)

# 클래스 이름이 green인 요소만 가져오기
name=driver.find_element(By.CLASS_NAME,'green')
print(name.text)

print('-'*20)

# find_elements : 요소 모두 가져오기 
name_list=driver.find_elements(By.CLASS_NAME,'green')
for name in name_list:
    print(name.text)
    
driver.quit()