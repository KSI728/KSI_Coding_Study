import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from tabulate import tabulate
from datetime import timedelta

# 파일 읽어오기
dust=pd.read_excel('dust_hour.xlsx')
print(tabulate(dust.head(),headers='keys',tablefmt='pretty'))

# 데이터 전처리 - 결측치 확인
print(dust.isna().sum())  # isnull() 동일

# 미세먼지 데이터에서 결측치를 포함하는 행 출력하기
# any() : bool값을 모두 return 해주는 내장함수 
print(dust[dust.isna().any(axis=1)]) # NaN 값을 포함하는 행 추출

# 데이터 전처리 - 결측치 채우기 
dust.ffill(inplace=True)
print(dust.isnull().sum())
print(dust.iloc[84:86])

#--------------------------------------------------------------------------------
# 날씨 데이터 읽어오기
weather=pd.read_excel('weather.xlsx')
print(tabulate(weather.head(),headers='keys',tablefmt='pretty'))

# 날씨 데이터 기본 정보 출력 
print(weather.info())

# 불필요한 컬럼 삭제 
weather.drop(['지점','지점명'],axis=1,inplace=True)

weather.columns=['date','temp','wind','rain','humidity']
print(tabulate(weather.head(),headers='keys',tablefmt='pretty'))

# 결측치 처리
print(weather.isna().sum())

# 강수량 데이터 변경
# 기상청에서는 0.1단위로 강수량을 측정, 강수량이 0.1 이하면 0으로 표시
weather['rain']=weather['rain'].replace(0,0.01)
print(weather['rain'].value_counts())

# -------------------------------------------------------------------------
# 두 데이터프레임 병합하기
# merge()
# • 내부 조인(inner join):둘 이상의 데이터프레임에서 조건에 맞는 행을 연결
# • 외부 조인(outer join):한쪽 데이터프레임에만 존재하는 데이터를 다른 데이터프레임에 결합

# how='inner' : 두 데이터프레임에서 공통으로 존재하는 행만 연결(공통으로 존재하는 날짜만 연결)
# on='date' : [‘date’] 컬럼을 기준으로 병합
merged_df=pd.merge(dust,weather,how='inner',on='date')
print(tabulate(merged_df.head(),headers='keys',	tablefmt='pretty'))

# 검증 용도 
merged_df.to_excel('dust_weather.xlsx',index=False)

# 요소별 상관관계 확인
print(merged_df.corr())

# 미세먼지를 기준으로 상관관계 분석
print('미세먼지(PM10)과 상관관계 분석')
corr=merged_df.corr()	#corr()	:DataFrame을 리턴
print(corr['PM10'].sort_values(ascending=False))	#내림차순 정렬

# 히트맵 시각화 : 상관계수가 0.3 이상인 항목과의 관계 확인 
plt.figure(figsize=(10,	10))
sns.heatmap(data=corr, annot=True, fmt='.2f')
plt.show()