# 리스트의 빌트인 함수

# [1] len()
# 원소/요소 갯수 헤아리는 len()

# [2] max(), min()
# 원소/요소 중 최대값/최소값 구하는 함수 

# [3] sum()
# 원소/요소의 합계를 구하는 함수 : 수치 타입의 요소일 경우만 가능

# [4] sorted()
# 원소/요소를 정렬하는 내장 함수 
nums=[3,4,2,5,1]
names=["한끼만","김태무"]
print(sorted(nums)) # 오름차순(기본값)
print(sorted(nums,reverse=True)) # 내림차순
print(sorted(names)) # 이름도 가능

# [5] del
# 원소/요소를 삭제