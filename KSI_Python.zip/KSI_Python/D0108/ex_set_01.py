# set 자료형
# 중복 제거할 때 사용 / Why? 중복 데이터 저장 불가
# 순서가 없음 => 원소를 출력할 수 없음
# 원소로 list,dict x / tuple o
set() #빈 set / { }는 빈 dict임

# [1] set 데이터 생성
data1={1,1,2,23,4,5,5,8,False}
print(type(data1))
print(len(data1)) #중복된 것은 1개만 len에 출력
data4=set() #Empty set