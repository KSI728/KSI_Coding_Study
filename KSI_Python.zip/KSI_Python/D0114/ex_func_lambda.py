# 람다 표현식 / 익명 함수 / 한줄 함수
# 사용 목적 : 다른 함수의 인수로 전달되는 경우
# 형식 / 문법 : lambda 매개변수들 = 실행 코드 및 반환값
# 많이 사용되는 함수 : map(), filter()

# 일반 함수
def plus_ten(x):
    return x+10 

# 람다 표현식 / 람다 함수 
lambda x:x+10 

# 함수 호출 / 사용 
print((lambda x:x+10)(5))
print((lambda x,y:x+y)(5,7))

# 내장함수 map(함수명, 여러 개의 데이터를 가진 타입): 함수명 여러 개의 데이터에 적용 
datas=['1','2','3']
datas2=list(map(int,datas))

# [1,2,3] => [2,5,10] map과 람다 표현식 사용
nums=[1,2,3]
result=list(map(lambda x:x*x+1, nums))
print(result)
