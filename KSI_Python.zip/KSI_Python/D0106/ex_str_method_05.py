# 메서드(method) : str 타입 전용 함수
# 문법 : 변수명.메서드명()

# [9] upper(), lower()
# 문자열을 대문자 또는 소문자로 변경하는 메서드
data="cat"
print(data.upper())
print(data.lower())

# [10] capitalize()
# 첫 문자만 대문자, 나머지는 소문자로 변경하는 메서드
data1="sWEET LITTLE KITTY"
print(data1.capitalize())