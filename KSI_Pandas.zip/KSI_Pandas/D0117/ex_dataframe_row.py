# DataFrame에서 행 선택 / 추출 => 가로 한 줄 선택

# [1] 모듈로딩
import pandas as pd

# [2] 데이터 준비
Filename=r'C:\Users\knudc\Desktop\KDT-7\Pandas\D0117\iris.csv'
irisDF=pd.read_csv(Filename)

# [3] 데이터 속성들 : index, columns, values, dtypes, shape, ndim

# [4] 속성 읽기
# print(IrisDF.index)
# print(IrisDF.columns)
# print(IrisDF.dtypes)
# print(IrisDF.shape)
# print(IrisDF.ndim)

# [5] DataFrame 기본 정보 출력 메서드 => .info()
irisDF.info()
print('-----------------------------------------')

# [6] DataFrame [수치형 컬럼] 에 대한 통계치 계산 메서드 => .describe()
print(irisDF.describe())
print('-----------------------------------------')

# [7] DataFrame [모든 컬럼] 에 대한 통계치 계산 메서드 => .describe(include='all')
print(irisDF.describe(include='all'))

# [8] 행 선택 / 추출 
#     => .loc[행인덱스]  
#     => .iloc[행인덱스] (정수만)
# 8-1 1개 행 선택
print("0", irisDF.iloc[0])
# 8-2 여러개 행 선택
print('여러', irisDF.iloc[[0,2]])
print('여러', irisDF.iloc[0:11:2])
# 8-3 인덱스 0~4번행까지 일부 변경
irisDF2=irisDF.rename(index={0:'zero'})
print(irisDF2.iloc[0])
print(irisDF2.loc['zero'])