# [예제] Good Luck 이라는 문자열에서 대문자는 소문자로, 소문자는 대문자로 변경해서 출력하세요.
msg="Good Luck"
print(msg, end=" => ")
for m in msg:
    if m.isupper():
        print(m.lower(),end='')
    else:
        print(m.upper(),end='')
