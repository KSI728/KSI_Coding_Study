# 행 인덱스 & 열 이름 일부 변경하기
# 메서드 .rename()

import pandas as pd

data=[[17,'남','덕영고'],[15,'여','대구중']] # 전역변수
dataDF1=pd.DataFrame(data)
print(dataDF1.index)
print(dataDF1.columns)

dataDF1.index=['학생1','학생2']
dataDF1.columns=['나이','성별','학교']
print(dataDF1)

dataDF2=dataDF1.rename(index={'학생1':'학생01'})
print(dataDF2)

# 여기서 뒤에 ,inplace=True를 입력하고 다른 데이터에 저장을 하게 되면 그 저장된 다른 데이터가 None으로 표시된다. 
dataDF3=dataDF1.rename(columns={'학교':'스쿨'})
print(dataDF3)
