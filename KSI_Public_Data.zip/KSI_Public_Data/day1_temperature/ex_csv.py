import csv

# 파이썬에서 파일을 읽을 경우 터미널 경로를 설정해줄 것
filepath=r'data/daegu.csv'
f=open(filepath,'r',encoding='utf-8')

# csv.reader(csvfile,	delimiter)	#읽기용, delimiter:	구분자(‘,’),csv파일은 delimiter 생략 가능
# csv.writer(csvfile,	delimiter)  #쓰기용, delimiter:	구분자(‘,’)

# mode='r' : read             (read)
# encoding = 'utf-8','euc_kr' (인코딩)
data=csv.reader(f,delimiter=',')

# 파이썬 반복문으로 앞 5행 출력 
count=0

for row in data:
    
    if count > 5:
        break
    
    else:
        print(row)
    count += 1
    
# 출력된 데이터는 모두 문자열 타입 -> 변경해야 함 
# \ufeff = 인코딩에 따라 달라짐 -> 삭제해야 함

f.close()