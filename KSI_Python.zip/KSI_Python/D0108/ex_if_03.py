# 제어문 - 조건문
# 특정 조건에 맞을 때 실행되는 코드와 실행되지 않는 코드 분리 

# [예제] 점수와 학점 출력
# A : 90이상,  B : 80이상,  C : 70이상,  D : 60이상,  F : 나머지 
score=87
if score>=90:
    print(f'당신의 학점은 A! Great!')
elif score>=80:
    print(f'당신의 학점은 B! Good!')
elif score>=70:
    print(f'당신의 학점은 C! Not bad!')
elif score>=60:  
    print(f'당신의 학점은 D! Try again(재수강)!')  
else:
    print(f'당신의 학점은 F................') 
    