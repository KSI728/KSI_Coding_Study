# 특정 기능 수행 코드의 재사용을 위한 방법 = 함수(Function)
# - 자주 사용되는 기능의 코드를 묶음
# - 이 코드를 1번만 작성해서 필요할때 마다 사용함

# 함수기능 : 2개 정수 나눗셈 후 결과 출력하는 기능
# 함수이름 : printdiv
# 매개변수 : num1, num2
# 반환값 : 없음

def printdiv(num1, num2):
    result=num1/num2 if num2 else '0으로 나눌 수 없음'
    print(result)

# 함수 호출
printdiv(5,6)

# 다른 파일에서 만든 함수 호출 
import ex_func_01
result=ex_func_01.add(6,3)
print(result)
