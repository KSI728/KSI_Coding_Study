# 데이터 프레임 생성하기 ( 표 만들기 )

import pandas as pd

# 전역 변수
data={'김덕영':[17,'남','덕영고'],'이대구':[15,'여','대구중']}

# 데이터프레임 만들기
# Dict 타입의 데이터로 데이터 프레임을 생성하면 key -> column 식별자(열 이름) / value -> column(열)
data_DF=pd.DataFrame(data)
print(data_DF)