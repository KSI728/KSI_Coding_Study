# # 로또 프로그램
# # 1 ~ 45 사이의 중복 없는 6개 숫자 추출
# import random
# # 랜덤 인스턴스/객체 생성 => 힙 영역에 저장 
# r=random.Random()
# # 랜덤 인스턴스/객체가 가진 메서드 사용
# # random() 메서드 : 0.0 <= ~ < 1.0 범위에서 숫자 하나 생성
# for idx in range(10):
#     value=r.random()
#     print(int(value*10))
# # randint() 메서드 : 정수a <= ~ <= 정수b 범위에서 숫자 하나 생성
# for idx in range(6):
#     value=r.randint(1,45)
#     print(value,end=' ')
# print()
# # -------------------------------------------------------------
# lotto=[] # 중복되지 않는 1~45 사이 숫자 6개 
# while True:
#     # 1 ~ 45 사이 임의의 숫자 추출 및 중복 검사 후 저장 
#     num=r.randint(1,45)
#     if num not in lotto:
#         lotto.append(num)

#     # 반복 중단 조건
#     if len(lotto)==6:
#         print(f"오늘의 로또번호 : {lotto}")
#         break
# # -------------------------------------------------------------     
# lotto2=set() # 중복되지 않는 1~45 사이 숫자 6개 
# while True:
#     # 1 ~ 45 사이 임의의 숫자 추출 및 중복 검사 후 저장 
#     num=r.randint(1,45)
#     lotto2.add(num)

#     # 반복 중단 조건
#     if len(lotto)==6:
#         print(f"오늘의 로또번호 : {lotto2}")
#         break