# 화면/터미널 출력 기능 내장함수 
# 문법 : print(데이터 or 변수명)
# 기본 기능 : 데이터를 화면에 출력하고 줄바꿈 시켜줌 / 단, 여러 데이터의 경우 띄어쓰기 시켜줌
print("가을")

# 변수명을 통해 출력하기
season="Fall"
print(season)

# 여러 개 출력하기
data1="봄"
data2="여름"
print(data1, data2)
