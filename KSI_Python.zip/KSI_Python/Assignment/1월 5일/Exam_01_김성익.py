# [문제 1]
# ㄱ : 프로그래밍
# ㄴ : 프로그래밍 언어
# ㄷ : 자연어
# ㄹ : 기계어

# [문제 2]
# ㄱ : 힙 영역
# ㄴ : 스택 영역

# [문제 3]
# 3-1
msg="Happy New Year"
print(msg)
# 3-2
num1=11
num2=3
print(num1, '+', num2, '=', num1+num2)
print('%d + %d = %d' %(num1,num2,num1+num2))
print(f'{num1} + {num2} = {num1+num2}')
# 3-3
print('''오늘은 수요일입니다.
벌써 일주일에 반이 지났습니다.
빨리 주말이 오면 좋겠습니다.''')

# [문제 4]
# 4-1
age=28
# 4-2
year='2000년'
month='12월'
date='24일'
# 4-3
name=input("이름을 입력하세요 : ")
gender=input("성별을 입력하세요 : ")
print(f'{name}({gender})님 반갑습니다~ ^^')