# 리스트 자료형 전용 함수 = 메서드
# 문법 : 변수명.메서드명()

# [3] .reverse()
# 원소/요소 순서를 뒤집기
list1=[1,5,3,2,4]
list1.reverse()
print(list1)

# [4] .sort()
# 원소/요소를 정렬해주는 메서드 
list1.sort() # 오름차순(기본값)
print(list1)
list1.sort(reverse=True) # 내림차순
print(list1)

# [5] .index()
# 원소/요소의 인덱스를 찾아주는 메서드 
# 찾으려는 원소/요소가 없다면 ERROR 발생 

# [6] .remove()
# 지정한 원소/요소 삭제 
list1.remove(5)
print(list1)

# [7] .clear()
# 모든 원소/요소 삭제
list1.clear()
print(list1)