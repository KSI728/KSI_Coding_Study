package java_practice;

public class InnerClass {
	public static void main(String[] args) {
		OuterClass outer = new OuterClass();
		//outer.inner.myMethod(); // private 클래스에 접근 안됨
	}
}
