# 객체 참조 카운팅
# 참조변수 Reference Variable : 객체의 주소를 저장

# (1) 기본 내장 builtin.py를 제외한 나머지 파일들 가져와서 쓰기 
import sys

# (2) 2025 데이터의 참조 카운트 출력
print(f'2025의 참조카운트 : {sys.getrefcount(2025)}')
a=2025
print(f'2025의 참조카운트 : {sys.getrefcount(2025)}')
b=2025
print(f'2025의 참조카운트 : {sys.getrefcount(2025)}')
# 2025를 저장하는 변수 2개를 추가하였기에 2025의 참조카운트가 증가함

# (3) 데이터 주소를 저장하고 있는 변수를 삭제
# 문법 : del 변수명
del a
print(f'2025의 참조카운트 : {sys.getrefcount(2025)}')
# 2025를 저장하고 있는 변수 a를 삭제 -> 참조카운트 감소