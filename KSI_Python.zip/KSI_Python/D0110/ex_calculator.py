# 계산기 프로그램 작성
# 개발 범위 : 사칙 연산 수행 
# UI 형식 : 명령어 기반 CUI/TUI => Terminal 사용
# UI 메뉴 : 연산 데이터 입력, 사칙 연산 결과, 설정, 종료
# 기능 구현 : 각 메뉴 선택에 따라 연산 수행

# 함수를 사용한 계산기 
from ex_func_01 import *

# 메뉴 출력 
print('*'*30)
print("숫자입력")
print('*'*30)
        
# 숫자 입력받기 
num=input("숫자 2개 입력 (예:3,5) : ").strip().split(',')
num=[ int(num) for num in num ]

# 메뉴 선택 / 메뉴에 따른 기능 코드 실행 
print('*'*30)
print("1.덧셈")
print("2.뺄셈")
print("3.곱셈")
print("4.나눗셈")
print("5.종료")
print('*'*30)
choice=input("메뉴 선택 : ")

if choice=='1':
        print(add(num[0],num[1]))
elif choice=='2':
        print(sub(num[0],num[1]))
elif choice=='3':
        print(multiple(num[0],num[1]))
elif choice=='4':
        print(divide(num[0],num[1]))
elif choice=='5':
    print("프로그램을 종료합니다.")
else:
    print("존재하지 않는 메뉴입니다!")        