# 클래스 (class) 설계 및 사용

# 고양이 정보를 저장하는 데이터 타입 생성
# 클래스 이름 : cat
# 클래스 속성 : 인스턴스 변수 [ name, gender, age ]
#              공유 클래스 변수 [ loc ]

# 클래스 기능 : eat(), sleep()

class cat:
    
    # 정적 변수 = 클래스 변수/속성
    loc='6번지'
    
    # 메모리(힙)에 속성을 저장해주는 기능 메서드 
    # [ 클래스 내의 self - 클래스 정의 안에서만 사용됨, 
    # 파이썬에서 값을 저장해주는 특수한 성격의 변수 ]
    def __init__(self,name,gender,age):
        # 인스턴스 변수/속성
        self.name=name
        self.gender=gender
        self.age=age
    
    # cat 클래스 전용 메서드
    def eat(self,food):
        print(f'{self.name}의 {food} 먹방')
        
    def sleep(self):
        print('이상한 박스에 들어가서 잠')

# 객체(인스턴스) 생성
# 문법 : 변수명=클래스이름()
c1=cat('터보','1000','female')

# cat 전용 메서드 사용하기
c1.eat('츄르')
c1.sleep()

# Person 인스턴스들의 속성 읽기와 변경
# - 읽기 : 객체변수명.속성명
# - 변경 : 객체변수명.속성명 = 새로운 값
c1.name='바바'