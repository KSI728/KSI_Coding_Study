# 리스트 자료형 전용 함수 = 메서드
# 문법 : 변수명.메서드명()

# [1] .append()
# 리스트에 원소/요소 추가 
list1=[]
list1.append("Happy")
list1.append("Cat")
print(list1)

# [2] .insert(인덱스,데이터)
# 원하는 위치에 원소/요소 추가 (본래 원소/요소는 뒤로 밀림)
list1.insert(-1,"Sad") # 이 경우 Sad는 제일 마지막에 추가되는 것이 X, 원래 제일 마지막 원소가 한 칸 밀리게 된다.
print(list1)