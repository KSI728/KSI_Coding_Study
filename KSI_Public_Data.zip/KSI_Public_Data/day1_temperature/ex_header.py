import csv

f=open('data/daegu-utf8.csv',encoding='utf-8-sig')

# next() 함수 : 데이터 한 행을 읽어오면서 데이터의 탐색 위치를 다음 행으로 이동시키는 명령어 
data=csv.reader(f,delimiter=',')
header=next(data)
print(header)
f.close()
