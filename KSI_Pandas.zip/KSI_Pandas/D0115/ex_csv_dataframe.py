# csv 데이터 파일 => Pandas의 DataFrame으로 읽어들이기 

# 모듈 로딩 
import pandas as pd #데이터 분석용 패키지 로딩

# 전역변수 : 파일 전체에서 사용되는 변수 
data_path=r'C:\Users\knudc\Desktop\KDT-7\Pandas\D0115\iris.csv'

#------------------------------------------------------------------

# 데이터 읽어들이기 < 방법 1 > 일반 파일 읽기 방식
# 파이썬 내장 함수 
# open(파일경로 + 이름, 열기모드, 인코딩)
# read(), write()
# close()

# 파일 열기
dataF=open(data_path,mode='rt',encoding='utf-8')

# 파일 읽기
# all_data=dataF.read()
all_lines=dataF.readlines()
print(f'[모든 데이터]\n{all_lines}')
for line in all_lines:
    print(line.split(','))

# 파일 닫기
dataF.close()

#------------------------------------------------------------------
               
# 데이터 읽어들이기 < 방법 2 > pandas 방식
# 판다스 내장 함수 
# read_csv(파일경로 + 파일명) => DataFrame(표) 형태로 반환

# 파일 읽기
dataDF=pd.read_csv(data_path)
print(dataDF)
dataCSV=pd.read_csv(r'C:\Users\knudc\Desktop\KDT-7\Pandas\D0116\member.csv')
print(dataCSV)