# 제어문 제어용 키워드
# break : 반복문을 즉시 중단함, 단 가장 가까이 있는 반복문만 해제 시킴

# [중첩 반복문 중단시키기]
is_stop=False # 내부 반복문 중단 여부 저장 
for num in range(256):
    if is_stop==True:
        break
    
    print(f'{num} 문자 => {chr(num)}')
    
    for value in range(num):
        print('*'*value)
        if num==3:
            is_stop=True
            break
    # 내부의 for 반복문이 중단되었다면 전체 종료 
    if is_stop==True:
        break