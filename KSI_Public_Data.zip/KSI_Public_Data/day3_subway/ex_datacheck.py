import csv

f=open('subwayfee.csv',encoding='utf-8-sig')
data=csv.reader(f)
header=next(data)
max_rate=0
rate=0

for row in data:
    
    # 4, 6 컬럼값을 정수로 변환 
    for i in range(4,8,2):
        row[i]=int(row[i])
    rate=row[4]/(row[4]+row[6])
    
    # 무임승차 인원이 0인 역 거르기
    if row[6]!=0:
        # 무임승차 퍼센트 : (무임승차 수 X 100 / (유임승차 수 + 무임승차 수))
        rate=(row[6]*100) / (row[4]+row[6])
        
        if rate>max_rate:
            max_rate=rate
            max_row=row
            print(row,round(rate,2),'%')

print(f'{max_row[3]}')  

f.close()


