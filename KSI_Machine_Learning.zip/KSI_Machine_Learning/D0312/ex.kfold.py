# 교차검증 K_Fold
# - 회귀모델에 사용
# - 데이터부족에 따른 과대적합(overfitting) / 과소적합(underfitting) 해결 위한 방법
# - 단점 : 학습 시간이 오래 걸림 

import numpy as np
from sklearn.model_selection import KFold

# 임시데이터
X = np.array([[1, 2], [3, 4], [1, 2], [3, 4]]) # 2D
y = np.array([1, 2, 3, 4])                     # 1D

# 2개 분할
kf = KFold(n_splits=4)
kf.get_n_splits(X)

# 2개 분할 데이터셋 확인
for i, (train_index, test_index) in enumerate(kf.split(X)):
    print(f"Fold {i}:")
    print(f"  Train: index={train_index}")
    print(f"  Test:  index={test_index}")