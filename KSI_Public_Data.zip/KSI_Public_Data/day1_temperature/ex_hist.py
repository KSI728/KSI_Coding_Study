import csv
import matplotlib.pyplot as plt
import koreanize_matplotlib

f=open('data/daegu-utf8.csv',encoding='utf-8-sig')
data=csv.reader(f)
next(data)
result=[]

for row in data:
    if row[-1]!='':
        result.append(float(row[-1]))
f.close

plt.figure(figsize=(10,2))
plt.hist(result,bins=500,color='blue')

# 레이블의 마이너스 기호 깨지는 현상 해결
plt.rcParams['axes.unicode_minus'] =False
plt.show()
