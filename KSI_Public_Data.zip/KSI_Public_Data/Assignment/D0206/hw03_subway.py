import pandas as pd
import matplotlib.pyplot as plt
import koreanize_matplotlib
from tabulate import tabulate

# 파일 불러오기
# 7시의 하차 데이터 가져오기 
# 8시의 하차 데이터 가져오기
# 7시 하차 데이터와 8시 하차 데이터 : 데이터프레임끼리 합치기
# 1~7호선까지 호선별로 가장 많이 내리는 지하철 역 분석 
# 하차인원에는 1000 단위 콤마를 추가하기 
# 막대 그래프로 시각화 하기

# 파일 불러오기
subway_df=pd.read_excel('subway.xls',sheet_name='지하철 시간대별 이용현황',header=[0,1])
print(subway_df.columns)

# 7,8시 하차 데이터 콤마 제거 후 int 형변환
commute_df=subway_df.iloc[:,[11,13]]
commute_df[('07:00:00~07:59:59', '하차')]=commute_df[('07:00:00~07:59:59', '하차')].apply(lambda x:x.replace(',',''))
commute_df[('07:00:00~07:59:59', '하차')]=commute_df[('07:00:00~07:59:59', '하차')].astype(int)
commute_df[('08:00:00~08:59:59', '하차')]=commute_df[('08:00:00~08:59:59', '하차')].apply(lambda x:x.replace(',',''))
commute_df[('08:00:00~08:59:59', '하차')]=commute_df[('08:00:00~08:59:59', '하차')].astype(int)

# 호선 데이터 불러오기
print(subway_df[('호선명','Unnamed: 1_level_1')])

# 7,8시 하차 데이터의 인덱스를 호선 데이터로 바꾸기 
line_list=subway_df[('호선명','Unnamed: 1_level_1')]
commute_df.set_index(line_list,inplace=True)

# 두 하차 데이터 더하기 
sum_data=commute_df.sum(axis=1,numeric_only=True)
passenger_number_list=sum_data.to_list()

# 더한 데이터를 시리즈로 변환 후 commute_df에 추가
total_sr=pd.Series(passenger_number_list,index=commute_df.index)
commute_df[('happy','total')]=total_sr

# 역 이름 데이터를 시리즈로 변환 후 commute_df에 추가
name_sr=pd.Series(list(subway_df.iloc[:,3]),index=commute_df.index)
commute_df[('hi','name')]=name_sr

# 그래프 데이터를 위한 빈 리스트 생성
stations=[]
passengers=[]

# 데이터 출력
line_chart=['1호선','2호선','3호선','4호선','5호선','6호선','7호선']   # 호선을 리스트로 해서 반복문 사용
for i in line_chart:
    
    line_df=commute_df.loc[i,('happy','total')]
    counting=line_df.max()
    name = commute_df[commute_df[('happy','total')]==counting][('hi','name')].values[0]
    print(f'출근 시간대 {i} 최대 하차역: {name}역, 하차인원: {counting}명')
    stations.append(f"{i+' '+name}")
    passengers.append(counting)

# 그래프 그리기
plt.figure(figsize=(10, 6))
plt.bar(stations, passengers)
plt.title('출근 시간대 지하철 노선별 최대 하차 인원 및 하차역')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
