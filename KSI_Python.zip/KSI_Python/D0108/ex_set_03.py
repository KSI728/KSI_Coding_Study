# set 자료형
# 중복 데이터 저장 불가
# 순서가 없음

data1=set(range(3,31,3))
data2=set(range(5,31,5))
print(data1)

# [4] .add()
# 원소 1개 추가
data1.add(31)
print(data1)

# [5] .update([n,n,n,...])
# 여러 개의 원소 한꺼번에 추가
data1.update([32,33,34])
print(data1)

# [6] .pop()
# set에서 원소/요소 랜덤으로 꺼내기
print(data1.pop())

# [7] .remove()
# set에서 원소/요소 하나씩 삭제

# [8] .clear()
# set에서 모든 원소/요소 삭제 메서드

