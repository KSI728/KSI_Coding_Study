# 모듈 로딩
import ex_utils

# 기능
if __name__ == "__main__":
    # 해당 파일이 실행될 때 , import 시에는 실행 안됨!
    print('OK')
    print('use.py',__name__)
