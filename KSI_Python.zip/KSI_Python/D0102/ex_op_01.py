# 산술연산자
'''
덧셈 +
뺄셈 -
곱셈 *
나눗셈 /
몫 //
나머지 %
제곱근 **
'''

# int, float 타입의 산술연산
# 정상적으로 작동됨

# str 타입의 산술연산
# 덧셈과 곱셈만 지원 (나머지 미지원)
qw='a'
er='b'
num1=12
num2=12.04
bull=True
print(f'{qw}+{er}={qw+er}') # 두 문자가 순서대로 연결됨
print(f'{qw}*{33}={qw*33}') # 곱셈의 경우 [문자*숫자]만 가능하며, 숫자만큼 문자를 반복 출력함 (float,bool과는 불가능)
print(qw+str(num1)) 
print(qw+str(num2)) 
print(qw+str(bull))
# str과 int,float,bool 사이 덧셈은 불가능하므로 각각 str로 변환 후 덧셈을 실행해야 함



# bool 타입의 산술연산 
bool1=True  # True=1
bool2=False # False=0