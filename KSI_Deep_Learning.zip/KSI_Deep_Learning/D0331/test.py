[].__iter__
