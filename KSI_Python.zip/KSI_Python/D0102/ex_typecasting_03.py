# 내장함수                          

# 데이터 타입 / 종류를 변경해주는 내장함수
# 타입 캐스팅 Type Casting / 형변환

# [4] str()
print(str(0)) # int -> str 
print(str(0.000)) # float -> str 
print(str(False)) # 0이 나오는 것이 아니라 "False"가 된 것

