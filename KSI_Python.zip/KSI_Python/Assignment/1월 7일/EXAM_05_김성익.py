# [문제 1]
# 1
jumsu=[98,71,90,82,88]
# 2
msg="Good Luck Happy New Year".split()
msg=list(msg)
print(msg)
print(len(msg))
# 3
score=input("중간고사 5과목 점수 입력 : ").split()
score=list(score)
print(score)
# 4
list1=[1,3,5,7,9,11]
list1.append(13)
list1.append(15)
print(list1)
# 5
list2=[1,3,5,7,9,11]
print(list2[2])
# 6
fruit=["kiwi","banana","orange","apple"]
fruit.sort(reverse=True)
print(fruit)
# 7
list3=[1,2,3,4,5,6]
list3.clear()
print(list3)
# 8 
kor=['가나다','한글','가방','국가','쏘핫']
print(max(kor))
print(min(kor))
print(len(kor))

# [문제 2]
data="hello@naver.com"
msg="123ABC"
# 1-1
print('@' in data)
# 1-2
print(data.isalpha())
# 1-3
print(msg.isdigit())
# 1-4
print(msg.isalnum())
# 1-5
print(' ' in msg)
# 2
message="!@Happy a Good Day~^^"
print(message.startswith("!@"))
print(message.endswith("^^"))
# 3
words="2023년은 토끼해입니다. 2024년은 무슨해 인가요? 나는 2024년이 기다려집니다."
print(words.index('2024'))
idx=words.index('2024')
print(words.index('2024',idx+1))
print(int(words[:4])+int(words[15:19])+int(words[34:38]))
