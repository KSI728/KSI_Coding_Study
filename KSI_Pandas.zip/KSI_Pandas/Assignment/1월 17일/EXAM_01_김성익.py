import pandas as pd

# [문제 1]
data=[['김나나',35,'과장'],['이민아',28,'대리'],['박정민',30,'대리']]
# 1-1
data=pd.DataFrame(data)
print(data.index)
print(data.columns)
print(data.values)
# 1-2
data.drop(columns=0,inplace=True)
print(data)
# 1-3
data=[['김나나',35,'과장'],['이민아',28,'대리'],['박정민',30,'대리']]
data=pd.DataFrame(data)
data1=data.drop(index=[1,2])
print(data1)

# [문제 2]
data = [["037730", "3R", 1510, 7.36],
        ["036360", "3SOFT", 1790, 1.65],
        ["005760", "ACTS", 1185, 1.28],]
columns = ["종목코드", "종목명", "현재가", "등락률"]
# 2-1
data=pd.DataFrame(data)
data.columns=["종목코드", "종목명", "현재가", "등락률"]
print(data.index)
print(data.columns)
print(data.values)
# 2-2
data1=data.drop(columns=['종목코드','현재가'])
print(data1)
# 2-3
data2=data.drop(index=[2])
print(data2)
# 2-4
data = [["3R", "1510"],
        ["3SOFT", 1790],
        ["ACTS", 1185]]
columns = ["종목명", "현재가"]
data=pd.DataFrame(data)
data.index=["037730", "036360", "005760"]
data.columns=["종목명", "현재가"]
print(data.index)
print(data.columns)
print(data.values)
# 2-5
data1=data.drop(index="037730")
print(data1)
# 2-6
data.drop(index=["037730","005760"],inplace=True)
print(data)

# [문제 3]
# 3-1
fish=(r'C:\Users\knudc\Desktop\KDT-7\Pandas\D0115\fish.csv')
fishDF=pd.read_csv(fish)
print(fishDF)
# 3-2
iris=r'C:\Users\knudc\Desktop\KDT-7\Pandas\D0115\iris.csv'
irisDF=pd.read_csv(iris)
print(irisDF)

# [문제 4]
# 4-1
# 클래스는 (속성)과 (기능)으로 구성된다.
# 4-2
# 객체 : 클래스를 기반으로 만들어진 구체적인 존재
# 인스턴스 : 특정 클래스에서 생성된 객체 
# 4-3
# 파이썬에서 값을 저장해주는 특수한 성격의 변수
# 4-4
# 모듈 : 관련성이 있는 변수, 함수, 클래스를 모아둔 파일
# 패키지 : 동일 카테고리에 여러 개의 모듈을 묶어 둔 것
# 4-5
import pandas as pd
from pandas import *
# 4-6
# 해당 파일이 실행될 때 __main__으로 표시된다.
# 4-7
# pip install kdt
# ..?
