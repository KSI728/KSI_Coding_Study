# 행 & 열 삭제 
# 메서드 .drop()
# *axis    매개변수 : 삭제 방향 axis=0 행, axis=1 열
# axis를 입력하지 않으면 기본값이 0으로 설정되어있다는 의미이다. 
# *inplace 매개변수 : True면 원본에 적용, False면 적용 X
import pandas as pd

data=[[17,'남','덕영고'],[15,'여','대구중']] # 전역변수
dataDF1=pd.DataFrame(data)
print(dataDF1)

dataDF2=dataDF1.drop(index=0) # 이 경우엔 삭제할 축을 따로 입력하지 않아도 된다. 
print(dataDF2)