import csv
import matplotlib.pyplot as plt
import re     # 정규식 모듈           
import koreanize_matplotlib

f=open('age.csv',encoding='euc-kr')
data=csv.reader(f)

result=[]
city=''
for row in data:
    
    if '산격3동' in row[0]:
        
        # row[0] : '대구광역시 북구 산격3동(2723063000)'
        # 정규식 (re) : 여러 구분자 사용 가능 
        # split 함수를 사용할 때 정규 표현식을 이용해 문자열을 나누려면, 
        # 대괄호 안에 구분자를 넣고, 그 대괄호를 다시 작은 따옴표('')로 묶어야 한다.
        str_list=re.split('[()]',row[0])
        print(str_list)
        city=str_list[0]
        
        for data in row[3:]:
            data=data.replace(',','')
            result.append(int(data))

f.close()          
print(result)
plt.title(f'{city} 인구현황')
plt.xlabel('나이')
plt.ylabel('인구수')
plt.plot(result)
plt.show()

