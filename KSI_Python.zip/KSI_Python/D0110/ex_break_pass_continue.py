# 제어문 제어용 키워드
# break : 반복문을 즉시 중단함, 단 가장 가까이 있는 반복문만 해제 시킴
# pass : 아무일도 없음, python 문법적으로 들여쓰기가 필요한 문법의 경우 실행 코드 미작성 시 사용됨 
# continue : 반복문에서 아래의 코드는 실행하지 않고 다음 요소로 이동할 수 있도록 함

# [예제] 1 ~ 50 사이의 숫자 중 3의 배수만 출력하지 마세요.
for num in range(1,51):
    if num%3 != 0: continue # for ~ in 으로 돌아감, 아래 코드 실행 X
    print(num, end=' ')
# while 반복문과 continue문 => 무한 루프 주의!
num=0
while num<50:
    num=num+1
    if num%3 == 0: continue
    print(num)

 

