import csv

def get_lowhigh_temp(data):
    
    header=next(data)
    
    # 최저 기온 초기 값은 가장 큰 값
    lowest_temp=100
    lowest_date=''  # 최저 기온 날짜 저장 초기 변수
    
    # 최고 기온 초기 값은 가장 작은 값
    highest_temp=-999
    highest_date=''  # 최고 기온 날짜 저장 초기 변수
    
    for row in data: 
        
        # 빈 정보면 반영하지 않음
        if row[3]=='':
            row[3]=100
        # 빈 정보가 아니면 실수화
        row[3] = float(row[3])
        
        # 빈 정보면 반영하지 않음
        if row[4]=='':
            row[4]=-999
        # 빈 정보가 아니면 실수화
        row[4] = float(row[4])
        
        # 최저 기온 계산 
        if row[3] < lowest_temp:
            lowest_temp=row[3]
            lowest_date=row[0]
            
        # 최고 기온 계산 
        if row[4] > highest_temp:
            highest_temp=row[4]
            highest_date=row[0]
    
    print('-'*50)
    print(f'대구 최저 기온 날짜 : {lowest_date}, 온도: {lowest_temp}')
    print(f'대구 최고 기온 날짜 : {highest_date}, 온도: {highest_temp}')


# 함수와 함수 사이 2줄 공백 국룰
def main():
    
    f=open('data/daegu-utf8.csv',encoding='utf-8-sig')
    data=csv.reader(f)
    get_lowhigh_temp(data)
    f.close()

main()