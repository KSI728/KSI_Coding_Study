package java_practice;

public class OuterClass {
	private int value = 10;
	public InnerClass inner;
	
	public OuterClass() {
		inner = new InnerClass();
		inner.myMethod();
	}
		
	private void getSum() {
		value = 10 + value;
		System.out.println("value : " + value);
	}
		
	// 내부 클래스 선언
	private class InnerClass {
		public InnerClass() {}
		
		public void myMethod() {
			System.out.println("OuterClass의 value 값 : " + value);
			
			getSum();
			
		}
	}
}
