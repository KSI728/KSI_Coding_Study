# 메서드(method) : str 타입 전용 함수
# 문법 : 변수명.메서드명()

# [7] isdigit(), isalphabet(), ... 
# 문자열을 구성하는 문자의 종류(숫자인지 알파벳인지 등)를 검사해주는 메서드
# is로 시작함
# 결과 : True, False

# (1) isdigit() 
# 아라비아 숫자 0~9로 구성된 str인지 체크 
data1="0123456789"
data2="010-1111-2222"
data3="5.0"
print(data1.isdigit())
print(data2.isdigit()) #-가 포함되어 있어서 False 
print(data3.isdigit()) #소수점이 포함되어 있어서 False

# (1-1) isnumeric(), isdecimal()
# 숫자 표현형태 포함 범위  isnumeric() 제곱근 분수 > isdigit() 제곱근 > isdecimal()
# 하지만 이들 또한 실수, 음수를 True로 잡아내지 못함함
data11="3²"
print(data1.isnumeric());print(data1.isdigit());print(data1.isdecimal())

# (2) isalpha()
# 문자(알파벳이나 한글 등 인간이 사용하는 언어)의 자음/모음으로만 구성된 str인지 체크 
data4="今日"
data5="Happy5" #숫자 포함x
data6="와!" #느낌표 포함x
print(data4.isalpha())
print(data5.isalpha())
print(data6.isalpha())


# (3) isalnum()
# 문자와 숫자만으로 구성되어있는지 여부
print(data5.isalnum())
