## ------------------------------------------------------
## 모듈 로딩 
## ------------------------------------------------------
from flask import Flask

## ------------------------------------------------------
## 함수이름 : create_app
## 매개변수 : 없음
## 반환결과 : flask server 인스턴스
## ------------------------------------------------------
        
def create_app():
    # Flask Server 인스턴스 생성
    APP = Flask(__name__)
    
    # 라우팅 등록
    from .views import main_view
    from .views import user_view
    APP.register_blueprint(main_view.main_bp)
    APP.register_blueprint(user_view.user_bp)
    
    # Flask Server 인스턴스 반환
    return APP




