# 내장함수 

# 절대값 변환 내장함수 : abs()
print(f'-4의 절대값 출력 : {abs(-4)}')

# 큰 값 / 작은 값 반환 내장함수 : max(), min()
print(f'4와 5 중 큰 값 : {max(4,5)}')
print(f'4와 5 중 작은 값 : {min(4,5)}')
print(f"abc와 aec 중 큰 값 : {max('abc','aec')}")

# 거듭제곱근 계산 내장함수 : pow()
print(f'2의 5승은 : {pow(2,5)}')

# 실수 반올림 내장함수 : round(n, 자릿수)
num=3.3837
print(f'소수점 이하 0자리에서 반올림 : {round(num,0)}')
print(f'소수점 이하 1자리에서 반올림 : {round(num,1)}')
print(f'소수점 이하 2자리에서 반올림 : {round(num,2)}')
print(f'소수점 이하 3자리에서 반올림 : {round(num,3)}')