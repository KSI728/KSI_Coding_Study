# 지역(Local) 변수와 전역(Global) 변수
# 지역 변수 : 함수 속에서 사용되는 변수들
# 전역 변수 : 파일(py)에서 사용되는 변수들 

# 전역 변수 : 해당 파일 모든 곳에서 사용 가능한 변수 
name='hong'

# 지역 변수 : 함수 속에서만! 사용되는 변수들
def printData():
    year=2025
    print(year)
    
def changeData():
    global name #전역변수 name 사용 선언 => 전역변수 변경 가능 
    name='이순신'
    year=2025
    print(year)

changeData()