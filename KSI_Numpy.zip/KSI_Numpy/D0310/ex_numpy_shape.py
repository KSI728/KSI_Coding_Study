import numpy as np

# Numpy ndarray의 shape 변환 
# - shape 변환 : 원소 갯수 유지
# 함수 : numpy.reshape()
# 메서드 ndarray.reshape()

# 객체 생성
n1 = np.array([[10,20], [30,40], [50,60]])

# 2차원 -> 3차원
# -1 : Unknown dimension - 하나만 지정 가능  
n1 = n1.reshape(6,1,-1)  # 변수 저장 필수 

#------------------------------------------------------------------
# Numpy ndarray의 shape 변환 
# - resize 변환 : 원소 갯수 변경 가능 
#                 초과할 경우 0으로 채워짐
# 함수 : numpy.resize()
# 메서드 ndarray.resize()

n1 = np.array([[10,20], [30,40], [50,60]])

# 데이터무결성 무시 : refcheck=False
n1.resize(6,2, refcheck=False)    # inplace가 디폴트값
print(n1)