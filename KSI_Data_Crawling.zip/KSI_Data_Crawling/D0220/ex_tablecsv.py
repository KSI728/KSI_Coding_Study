import pandas as pd

url='http://en.wikipedia.org/wiki/Comparison_of_text_editors'
# 지정한 url에서 'Developer'라는 단어를 포함하는 테이블만 반환 
editor_table=pd.read_html(url,match='Developer')
print(f'editor_table 크기 : {len(editor_table)}')

table_df=pd.DataFrame(data=editor_table[0])
print(table_df.columns)

# Multilevel column을 single level column으로 변경
# 방법 : DataFrame.droplevel(level=0)
table_df.columns=table_df.columns.droplevel(level=0)
print(table_df.columns)

# 불필요한 컬럼 삭제 
table_df=table_df.drop(['GUI','TUI or CLI'],axis=1)

# table_df를 csv 파일로 저장
table_df.to_csv('text_editors.csv',mode='w',encoding='utf-8')
