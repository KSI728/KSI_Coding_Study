# # Unit 30
# # [연습 문제 1]
# kor,eng,math,sci = 100,86,81,91

# def get_max_score(*args):
#     return max(args)
    
# max_score=get_max_score(kor,eng,math,sci)
# print('높은 점수:',max_score)

# max_score=get_max_score(eng,sci)
# print('높은 점수:',max_score)

# # [심사 문제 1]
# kor,eng,math,sci =map(int,input().split())

# def get_min_max_score(*args):
#     min_num=min(args)
#     max_num=max(args)
#     return min_num, max_num

# def get_average(**kwargs):
#     for i in kwargs.values():
#         avg=sum(kwargs.values())/len(kwargs)
#         return avg

# min_score, max_score = get_min_max_score(kor,eng,math,sci)
# average_score=get_average(kor=kor,eng=eng,math=math,sci=sci)
# print('낮은 점수: {0:.2f}, 높은 점수: {1:.2f}, 평균 점수: {2:.2f}'.format(min_score,max_score,average_score))

# min_score,max_score=get_min_max_score(eng,sci)
# average_score=get_average(eng=eng,sci=sci)
# print('낮은 점수: {0:.2f}, 높은 점수: {1:.2f}, 평균 점수: {2:.2f}'.format(min_score,max_score,average_score))

# Unit 32
# [연습 문제 1]
files=['font','1.png','10.jpg','11.gif','2.jpg','3.png','table.xlsx','spec.docx']
print(list(filter(lambda x:x.find('.jpg')!=-1 or x.find('.png')!=-1,files)))

# [심사 문제 1]
listpng=['1.jpg','10.png','11.png','2.jpg','3.png']
print(list(map(lambda x:f"{int(x.split('.')[0]):03d}.{x.split('.')[1]}",listpng)))
