# 객체비교연산자
# 객체 : 메모리 힙 영역에 존재하는 데이터
# == 등의 비교연산자와의 차이점 : 데이터/값을 비교하는 비교연산자와는 달리,
#                               메모리 상의 객체를 비교한다.

a=b=10
print(f'{a}의 주소 : {id(a)}')
print(f'{b}의 주소 : {id(b)}')
c=10.0
print(a==c)
print(a is c)

'''
is 연산자 : A is B            # A, B 같은 객체면 True
is not 연산자 : A is not B    # A, B 같은 객체 아니면 True
'''