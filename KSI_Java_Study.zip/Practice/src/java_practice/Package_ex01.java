package java_practice; // 자동으로 추가됨

public class Package_ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
