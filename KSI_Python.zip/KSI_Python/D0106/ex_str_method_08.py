# 메서드(method) : str 타입 전용 함수
# 문법 : 변수명.메서드명()

# [13] format()
# 원하는 형식/양식/형태의 문자열 생성 
# 문법 : ' {}  {} '.format(data1,data2)  
job='programmer'
work_year=4

# 출력 순서가 동일한 경우 인덱스 생략 가능
msg="나는 {}년차 {}다.".format(work_year,job)
print(msg)
# 출력 순서가 다를 경우 인덱스 기입 필수수
msg2="나의 직업은 {1}고, {0}년째 일하고 있다.".format(work_year,job) #숫자는 순서를 의미함
print(msg2)
# 문자열의 중괄호 사이에 데이터의 name 기입
msg3="나는 {year}년차 {job}다.".format(job=job,year=work_year)
print(msg3)

# 정렬 => 왼쪽, 가운데, 오른쪽 
# 사용법 : {:정렬기호칸수} 
# 왼쪽 {:<10} 가운데 {:^10} 오른쪽 {:>10}
month=12
day=25
data1="나의 생일은 {:<10}월 {:<10}일 입니다.".format(month, day)
data2="나의 생일은 {:^10}월 {:^10}일 입니다.".format(month, day)
data3="나의 생일은 {:>10}월 {:>10}일 입니다.".format(month, day)
print(data1,data2,data3,sep='\n')

# 정렬 => 왼쪽, 가운데, 오른쪽 
# 정렬하고 빈공백 채우기
# 사용법 : {:추가할문자,정렬기호,칸수} 
# 왼쪽 {:문자<10} 가운데 {:문자^10} 오른쪽 {:문자>10}
data1="나의 생일은 {:★<10}월 {:★<10}일 입니다.".format(month, day)
data2="나의 생일은 {:★^10}월 {:★^10}일 입니다.".format(month, day)
data3="나의 생일은 {:★>10}월 {:★>10}일 입니다.".format(month, day)
print(data1,data2,data3,sep='\n')

# 실수 소수점 => 5이상의 경우 반올림해서 출력
# 사용법 : {:칸수.소수점표현자릿수,f} 
# {:n.xf}
avg=78.3901491
avg1="중간고사 평균값은 {:20.2f}".format(avg)
print(avg1)
avg1="중간고사 평균값은 {:20.3f}".format(avg)
print(avg1)
avg2=f'중간고사 평균값은 {avg:10.1f}'
print(avg2)