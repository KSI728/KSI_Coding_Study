# 조건부 표현식
# - if ~ else 문법을 줄여서 1줄로 표현하는 문법
# - 문법 : 참일때 실행 코드 if 조건문 else 거짓일 때 실행 코드 

# [예제] 양수, 음수 구별해서 출력하기 
num=8
print("양수") if num>0 else print("음수") #방법 1
result="양수"  if num>0 else "음수" ; print(result) #방법 2

# [예제] 양수, 0, 음수 구별해서 출력하기 
num=0
print("양수") if num>0 else print("음수") if num<0 else print('0')

# [문제] 월에 따른 계절을 알려주세요.
# 1
month=12
if month in [3,4,5]:
    print(f'지금은 봄입니다!')
elif month in [6,7,8]:
    print(f'지금은 여름입니다!')
elif month in [9,10,11]:
    print(f'지금은 가을입니다!')
elif month in [12,1,2]:
    print(f'지금은 겨울입니다!')
else:
    print("월은 12월까지 밖에 없어요!")
# 2
season='지금은 봄입니다!' if month in [3,4,5] else '지금은 여름입니다!' if month in [6,7,8] else '지금은 가을입니다!' if month in [9,10,11] else '지금은 겨울입니다!' if month in [12,1,2] else "월은 12월까지 밖에 없어요!"
print(season)




