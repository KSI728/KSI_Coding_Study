# 내장함수                          

# 데이터 타입 / 종류를 변경해주는 내장함수
# 타입 캐스팅 Type Casting / 형변환
'''
[종류]
(1) 암묵적 형변환 : 시스템에서 진행
(2) 명시적 형변환 : 개발자가 진행 
'''

# [1] int()

a=3.78
print(int(a))
# float을 int로 변환할 경우 소수점 이하를 버림 -> 데이터 손실 발생

b='3.0'
b2='-3'
print(int(b)) # 불가능
print(int(b2))
# str을 int로 변환할 때 10진수 숫자만 변환 가능 / 음수는 가능

c=False
print(int(c))
# bool을 int로 변환하면 True는 1, False는 0으로 변환

# [2] 진수 변환
# ,base = 원하는 진수 숫자 입력
print(f'{int("0b11100", base=2)}')