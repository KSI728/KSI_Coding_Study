# 강아지 클래스 만들기 
# (1) 특징/속성/성질/외형 : 품종, 털색상, 눈색상, 무게, 나이, 성별, 이름
# (2) 행동/기능/동작 : 찾는다, 문다, 꼬리친다

# 클래스 이름 : Dog
# 클래스 속성 : kind, coat_color, eye_color, weight, age, gender, name
# 클래스 기능 : bark(), bite(), tailing() 

class Dog:
    
    # 파이썬 시스템에 의해 실행되는 메서드 : 콜백(callback) 메서드 함수 
    def __init__(self, kind, coat_color, eye_color, weight, age, gender, name):
        print("Dog __init__()")
        self.kind=kind
        self.coat_color=coat_color
        self.eye_color=eye_color
        self.weight=weight
        self.age=age
        self.gender=gender
        self.name=name
        
        
    def bark(self):
        print(f'{self.name} said bow-wow!')
        
        
    def bite(self, something):
        print(f'{self.name} bites {something}')

# 객체 생성하기 : 클래스 이름()
mydog = Dog('chawu','black','brown',5,2,'m','cha')
mydog.bark()

# 객체의 속성과 메서드 사용하기
# 속성 읽기 : 객체변수명.속성명
# 속성 변경 : 객체변수명.속성명 = 새로운 값
# 메서드 호출 : 객체변수명.메서드명()

# 속성 변경
mydog.age=3
mydog.bite('cat')

# 고양이 클래스
class Cat:
    
    def __init__(self, name, age):
        self.name=name
        self.age=age
        
        
    def crawl(self,person):
        print(f"{self.name} attacks {person}")
        
        
cat1=Cat('momo',3)     
cat1.crawl('o')   