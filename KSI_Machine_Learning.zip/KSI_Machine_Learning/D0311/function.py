from sklearn.linear_model import LinearRegression                                               # 머신러닝 알고리즘 모듈
from sklearn.metrics import mean_squared_error, mean_absolute_error, root_mean_squared_error    # 성능평가 모듈 
from sklearn.model_selection import train_test_split                                            # 데이터셋 분리 모듈
import matplotlib.pyplot as plt 
import pandas as pd 

# 함수 기능 : 평가결과 반환함수
# 함수 이름 : checkModel
# 매개 변수 : 학습용 데이터셋, 테스트용 데이터셋
# 함수 결과 : 결과값 데이터프레임, 결과문자열 

def checkModel(trainDS, testDS, model):
    
    result = []   # 성능평가 결과 저장
    
    dataset_names = ["Train", "Test"]
    
    for data, label in [trainDS, testDS]:
        
        # 예측값
        pre_label = model.predict(data)

        # 모델 적합도
        score = model.score(data, label)

        # 비용 계산 
        rmse = root_mean_squared_error(label, pre_label)
        
        result.append([score, rmse])
        
    return pd.DataFrame(result, columns=["Score", "RMSE"], index=dataset_names)