import csv
import matplotlib.pyplot as	plt
import koreanize_matplotlib

f=open('data/daegu-utf8.csv',encoding='utf-8-sig')
data=csv.reader(f)
next(data)
aug=[]
jan=[]

for row in data:
    
    if row[0]!='' and row[4]!='':
        month=row[0].split('-')[1]
        
        if month=='08':
            aug.append(float(row[-1]))
        
        if month=='01':
            jan.append(float(row[-1]))

f.close()

plt.hist(aug,bins=100)
plt.hist(jan,bins=100)
plt.show()
