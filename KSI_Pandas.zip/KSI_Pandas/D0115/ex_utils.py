'''
FILENAME : ex_utils.py
DESCRIPTION : 데이터 분석에 자주 사용되는 기능의 함수들 
DATE : 2025.01.15
HISTORY : WRITER    DATE        DESC
          KSI       2025.01.01  print_info() 추가
          MR.BEAST  2025.01.15
'''
# 함수기능 : 개발 정보 출력 기능 
# 함수이름 : print_info()
# 매개변수 : 없음
# 리턴값 : 없음 

def print_info():
    print('-------------------------')
    print("회사명 : KNU")
    print("연락처 : 053-123-4567")
    print("담당자 : MR.BEAST")
    print('-------------------------')

# 함수 호출/사용
if __name__ == '__main__':
    # 해당 파일이 실행 될 때만 실행
    print_info()
    print('utils.py',__name__)