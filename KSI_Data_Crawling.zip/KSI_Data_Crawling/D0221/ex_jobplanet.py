# 구글 크롬 개발자 도구로 xpath를 가져오기 

samsung_url={'삼성전자':'https://www.jobplanet.co.kr/companies/30139/reviews/삼성전자'}
samsung_xpath={'평점':'//*[@id="premiumReviewStatistics"]/div/div[2]/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/div[2]/span[2]'}

# 잡플래닛 평점 크롤링
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import pandas as pd
from tabulate import tabulate

user_id='happycat728728@gmail.com'
pwd='1234'

# 로그인 하기 
def login(driver, user_id, pwd):
    driver.get("https://www.jobplanet.co.kr/users/sign_in?_nav=gb")
    time.sleep(1)
    
    # 아이디 입력
    login_id = driver.find_element(By.ID, "user_email")
    login_id.send_keys(user_id)
    
    # 비밀번호 입력
    login_pwd = driver.find_element(By.ID, "user_password")
    login_pwd.send_keys(pwd)
    
    # 로그인 버튼 클릭
    login_id.send_keys(Keys.RETURN)
    time.sleep(5)


def get_review_score(driver):
    compary_score_dict = {}
    for company_name in samsung_url.keys():
        score_list = []
        company_url = samsung_url.get(company_name)
        driver.get(company_url)
        time.sleep(2)
        
        # 회사 이름 가져오기
        company = driver.find_element(By.XPATH, '//*[@id="companyName"]/a').text
        print('-' * 80)
        print(company)
        
        # 전체 5개의 평점 가져오기
        for key in samsung_xpath.keys():
            point = driver.find_element(By.XPATH, samsung_xpath.get(key)).text
            print(f'{key}: {point}', end=' ')
            score_list.append(point)
        print()
        print('-' * 80)
        
        # 딕셔너리에 모든 평점 추가하기
        compary_score_dict[company_name] = score_list
    
    # 딕셔너리를 DataFrame으로 변환
    columns = ('전체평점', '복지', '워라벨', '사내문화', '승진 기회', '경영진')
    # orient='index': 딕셔너리의 키가 행의 색인이 되고 딕셔너리의 값이 행의 데이터가 됨
    company_score_df = pd.DataFrame.from_dict(compary_score_dict, orient='index', columns=columns)
    print(tabulate(company_score_df, headers='keys', tablefmt='psql'))
    
    # CSV 파일로 저장
    company_score_df.to_csv('company_scores.csv', index=False, mode='w', encoding='utf-8-sig')


def main():
    driver = webdriver.Chrome()
    login(driver, user_id, passwd)
    get_review_score(driver)
    time.sleep(5)
    driver.close()

# 적절한 사용자 ID와 패스워드 입력
user_id = 'your_user_id'
passwd = 'your_password'

if __name__ == "__main__":
    main()