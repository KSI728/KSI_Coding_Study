# 평면에 점을 그려주는 프로그램 설계
# 사용자가 원하는 위치에 점을 표시하기
# 점을 표현 저장하는 데이터 타입 필요

# 부모 클래스 
# (1) 속성/특징/외형 : x좌표, y좌표, 색상, 반지름 - x, y, color, r   
# (2) 행동/기능/역할 : 점그리기, 정보출력         - drawing(), printinfo()
# (3) 이름 : Point 
class Point:
    
    # 객체(인스턴스) 생성 및 속성 초기화 메서드 
    # self : 힙 메모리에 저장되는 주소 저장 매개변수 
    def __init__(self, x, y, color, r):
        self.x = x
        self.y = y
        self.color = color
        self.r = r
    
    
    # 메서드 이름 : drawing
    # 매개변수 : 없음
    # 메서드 결과 : 반환값 없음 
    def drawing(self):
        print(f'{self.color} ★ ')
        
        
    # 메서드 이름 : printinfo()
    # 매개변수 : 없음
    # 메서드 결과 : 반환값 없음 
    def printinfo(self):
        print(f'위치 : {self.x}, {self.y}')
        print(f'크기 : {self.r}')
        print(f'색상 : {self.color}')
        
        
# 자식 클래스 
# (1) 속성/특징/외형 : x좌표, y좌표, 색상, 반지름, z좌표 - x, y, color, r, z   
# (2) 행동/기능/역할 : 점그리기, 정보출력         - drawing(), printinfo()
# (3) 이름 : Point3D 
class Point3D(Point):
    
    # 부모 생성 
    def __init__(self, x, y, z, color, r):
        super().__init__(x, y, color, r)    # z는 위에만 놔둔다
    # 자식 속성 생성 및 저장 
        self.z=z
        
    # 메서드 오버라이딩 
    def printinfo(self):
        print(f'위치 : {self.x}, {self.y},  {self.z}')
        print(f'크기 : {self.r}')
        print(f'색상 : {self.color}')
        
# 매직 스페셜 변수 : __name__
# 이러면 아래 if 문 내용은 이 파일에서만 실행된다
if __name__ == '__main__':
        
    # 객체 생성
    blackpoint = Point(10, 10, 'black', 5)
    redpoint = Point3D(5, 5, 5, 'red', 5)

    # 속성 변경
    redpoint.r='red'

    # 메서드 사용
    blackpoint.drawing()
    redpoint.drawing()