# [예제] 좋아하는 숫자를 10명의 사람에게 입력 받은 후 숫자들을 저장해주세요.
#        그리고 가장 많은 사람들이 좋아하는 숫자가 무엇인지 출력해주세요.
likes=[]
for num in range(10):
    nums=input("좋아하는 숫자 : ").strip()
    likes.append(int(nums))
print(likes)

dict={}
for number in likes:
    if number not in dict.keys():
        dict[number]=likes.count(number)
print(dict)

max_key=[]
max_value=0
for item in dict.items():
    if max_value==item[1]:
        max_key.append(item[0])
    elif max_value==item[1]:
        max_key.clear()
        max_key.append(item[0])
        max_value=item[1]
print(f'가장 좋아하는 숫자 : {max_key}({max_value}번)')


# [예제] 좋아하는 숫자를 10명의 사람에게 입력 받은 후 숫자들을 저장해주세요.
#        그리고 가장 많은 사람들이 좋아하는 숫자가 무엇인지 출력해주세요.
