# 키워드파라미터 함수
# 매개변수 개수 : 0개 ~ n개
# 문법 / 형식 : def 함수이름(**매개변수명)
# 매개변수의 타입 : dict

#------------------------------------------------------------------------------
# 함수기능 : (1)N개의 과목과 (2)N개 과목의 각 점수에 대한 합계와 평균 출력
# 함수이름 : sum_avg()
# 매개변수 : **score
# 함수결과 : 합계와 평균
def sum_avg(**score):
    
    for i in score.values():
        total=sum(score.values())
        avg=total/len(score) if len(score) else 0
        return total, avg

print(sum_avg(kor=90,math=100,eng=78))