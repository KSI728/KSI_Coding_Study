# 리스트 타입의 연산
# 덧셈 : 리스트 + 리스트
# 곱셈 : 리스트 * int
data1=[1,3,5,7]
data2=[2,4,6,8]
print(data1+data2) #더한 순서대로 리스트에 원소/요소가 추가된다. 
print(data1*2) #곱한만큼 리스트에 원소/요소가 추가된다. 

# 멤버 연산자 in, not in
print(1 in data1)

# 원소/요소 값 변경 : 변수명[인덱스]=새로운 값
data3=[6,7,8,9]
data3[0]=5
print(data3)