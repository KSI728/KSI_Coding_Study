from urllib.request import urlopen
from bs4 import BeautifulSoup

html=urlopen('https://www.daangn.com/hot_articles')
print(type(html))
print(html.read())

# BeautifulSoup 사용
html=urlopen('https://www.daangn.com/hot_articles')
bs=BeautifulSoup(html.read(),'html.parser')
print(bs)
print(bs.h1)   # h1 태그만 반환 
print(bs.h1.string)

# 예외 처리
from urllib.error import HTTPError
from urllib.error import URLError

try:   
    html=urlopen('http://www.pythonscraping.com/pages/error.html')
except HTTPError as e:
    print(e)
except URLError as e:
    print('The server could not be found!')
else:
    print('It worked!')
    
# 존재하지 않는 태그 접근
def get_title(url,tag):
    try:
        html=urlopen(url)
        bs=BeautifulSoup(html.read(),'html.parser')
        value=bs.find(tag)
    except HTTPError as e:
        return None
    except AttributeError as e:
        print(e)
        return None
    else:
        return value
        
tag='h2'
url='http://www.pythonscraping.com/pages/page1.html'
value=get_title(url,tag)

if value == None:
    print(f'{tag} could not be found')
else:
    print(value)