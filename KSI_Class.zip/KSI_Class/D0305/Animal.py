class Animal:
    
    def __init__(self, kind, coat_color, eye_color, weight, age, gender, name):
        self.kind=kind
        self.coat_color=coat_color
        self.eye_color=eye_color
        self.weight=weight
        self.age=age
        self.gender=gender
        self.name=name
        
        
    def crawl(self,person):
        print(f"{self.name} attacks {person}")