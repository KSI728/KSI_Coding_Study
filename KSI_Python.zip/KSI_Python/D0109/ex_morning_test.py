# [예제] 숫자 2개와 사칙연산자 1개를 입력 받아서 연산 결과를 출력하세요.
x=input("숫자 2개와 사칙연산자 하나를 다음과 같이 입력해주세요(9 8 +) : ").strip().split()
if (int(x[0])>0 and int(x[1])>0) and (x[0].isdecimal() and x[1].isdecimal()) and (x[-1] in '+,-,*,/'):
    
   
    if x[-1]=='+':
        print(f'덧셈연산 : {x[0]} + {x[1]} = {int(x[0])+int(x[1])}')
    elif x[-1]=='-':
        print(f'뺄셈연산 : {x[0]} - {x[1]} = {int(x[0])-int(x[1])}')
    elif x[-1]=='*':
        print(f'곱셈연산 : {x[0]} * {x[1]} = {int(x[0])*int(x[1])}')
    elif x[-1]=='/':
        if x[1] is not '0':
            print(f'나눗셈연산 : {x[0]} / {x[1]} = {int(x[0])/int(x[1])}')
        else:
            print("0으로 나눌 수 없습니다.")
         
else:
    print("지원되지 않는 형식입니다.")
