# 모듈 : 관련성이 있는 변수, 함수, 클래스를 모아둔 파일(.py)
# [ 사용법 ] 
# (1) import 모듈명 (단, 파일 확장자 제외)
# (2) import 모듈명 as 별칭 (모듈명이 길떄 줄여서 지정)
# [ 위치 ]
# 일반적으로는 파일 상단에 import 구문을 기입 (가독성 고려, 필수는 아님)

# 수학 관련 기능 불러오기 math.py
# 임의의 수 추출 기능 필요  random.py
import math
import random as r # random 대신에 r로 모듈 내 기능 사용 

# 모듈 내의 변수, 함수, 클래스 사용
# 문법 
# (1) 모듈명.변수명
# (2) 모듈명.함수()
# (3) 모듈명.클래스
print(math.pi)
print(math.factorial(3))

# 모듈 내의 클래스 사용 => 힙 메모리에 데이터를 저장 : 객체(object)
rObject=r.random()
print(rObject.random()) #임의의 실수 추출 