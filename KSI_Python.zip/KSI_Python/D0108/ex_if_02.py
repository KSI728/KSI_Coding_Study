# 제어문 - 조건문
# 특정 조건에 맞을 때 실행되는 코드와 실행되지 않는 코드 분리 

# [예제] 시험 점수가 60점 이상이면 합격, 아니면 불합격
score=59
if score>=60:
    print("합격")
else:
    print("불합격")
    
# [예제] 숫자가 양수인지 음수인지 구분해서 출력해주세요.
num=5
if num>0:
    print("양수")
else:
    print("음수")
    
# [예제] 주민번호를 통해 나이를 계산해주세요.
jumin="031203-3234567"
if jumin[7] in ['1','2','5','6']:
    age1=2025-int('19'+jumin[:2])
    print(f'Your age is {age1}!')
elif jumin[7] in ['3','4','7','8']:
    age2=2025-int('20'+jumin[:2])
    print(f'Your age is {age2}!')
else:
    print("nope")
