package java_practice;

class Animal {
	String name;
	
	void nature() {
	System.out.println("Animal nature() called");
	}
}

class Fish extends Animal {
	String color;
	
	@Override
	void nature() {
	System.out.println("Fish nature() called");
	}
}

class Human extends Animal {
	@Override
	void nature() {
	System.out.println("Human nature() called");
	}
}

public class UpcastingEx {

	public static void printObject(Animal objs[]) {
		// Animal objs[]에서 upcasting 사용
		for(Animal a : objs) {
			System.out.print(a.name + " -> ");
			a.nature();
		}
	}
	
	public static void main(String[] args) {
		Animal animal = new Animal();
		animal.name = "BlueFish";
		
		Animal fish = new Fish();
		fish.name = "Whale";
		//fish.color = "Blue" 접근 안됨;
		
		Animal person = new Human();
		person.name = "Person1";
		
		Animal animals[] = {animal, fish, person};
		printObject(animals);
	
	}
}
