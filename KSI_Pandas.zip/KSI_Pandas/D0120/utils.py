# Pandas 데이터 관련 사용자 정의 함수 

# [ 함수 생성 ]
# 함수 기능 : 데이터프레임의 요약 정보, 실제 데이터, 통계치 확인 기능
# 함수 이름 : summary
# 매개 변수 : df,dfname
# 반환값 : 없음 
def summary(df,dfname):
    print(f'-----------[{dfname}]-----------')
    df.info()
    print(df.head(),df.tail())
    df.describe()
    
# [ 함수 생성 ]
# 함수 기능 : 데이터프레임 속성 한번에 출력
# 함수 이름 : print_attribute
# 매개 변수 : df,dfname
# 반환값 : 없음 
def print_attribute(df,dfname):
    print(f'----[{dfname}]----')
    print(df.ndim) 
    print(df.shape) 
    print(df.dtypes)