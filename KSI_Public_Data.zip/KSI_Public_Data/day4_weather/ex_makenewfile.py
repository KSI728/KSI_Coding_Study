import pandas as pd
from tabulate import tabulate
from datetime import timedelta

# 파일 읽어오기
dust=pd.read_excel('dust.xlsx')
print(tabulate(dust.head(),headers='keys',tablefmt='pretty'))

# 데이터 기본 정보 요약 확인
print(dust.info())

# 컬럼명 영어로 재설정
dust.rename(columns={'날짜':'date','아황산가스':'so2','일산화탄소':'co','오존':'o3','이산화질소':'no2'},inplace=True)
print(tabulate(dust.head(),headers='keys',tablefmt='pretty'))

# ['date'] 컬럼의 자료형을 datetime으로 변경하기 
def zerofrom24(datestring):
    # 24시로 표현된 값을 익일 00으로 변환
    try:
        return pd.to_datetime(datestring, format='%Y-%m-%d %H')
    except:
        datestring=datestring[:11]+'00' # 날짜 정보와 공백 포함 (시간 앞의 공백까지 포함)
        return pd.to_datetime(datestring, format='%Y-%m-%d %H')+timedelta(days=1)

# apply 함수를 사용해서 ['data'] 컬럼에 zerofrom24() 함수를 적용
dust['date']=dust['date'].apply(zerofrom24)
print(dust.info())
print(dust[dust['date'].dt.day==5])


dust.to_excel('dust_hour.xlsx',index=False)
    