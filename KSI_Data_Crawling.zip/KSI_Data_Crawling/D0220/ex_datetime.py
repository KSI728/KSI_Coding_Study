import datetime

date_string="Tue, 13 Aug 2024 09:02:00 +0900"

# datetime 변환
# strptime(string,format) : string을 datetime으로 변환
# strftime(format) : datetime을 string으로 변환 

# strptime(string,format) : string -> datetime 변환
pdate=datetime.datetime.strptime(date_string,'%a, %d %b %Y %H:%M:%S +0900')
print(type(pdate))

# strftime(format) : datetime -> string 변환
pdate_string=pdate.strftime('%Y-%m-%d %H:%M:%S')
print(type(pdate_string))
print(pdate_string)