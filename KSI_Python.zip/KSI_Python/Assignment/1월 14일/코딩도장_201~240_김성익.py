# 201~210
# 201
def print_coin():
    print('bitcoin')
# 202
print_coin()
# 203
for i in range(100):
    print_coin()
# 204
def print_coins():
    for i in range(100):
        print('bitcoin')
# 205
# 함수 선언보다 함수 호출이 우선되었다.
# 206
# A,B,C,A,B가 출력된다.
# 207
# A,C,B가 출력된다.
# 208
# A,C,B,E,D가 출력된다.
# 209
# B,A가 출력된다.
# 210
# B,C,B,C,B,C,A가 출력된다.

# 211~220
# 211
# 안녕, Hi가 출력된다.
# 212
# 7,15가 출력된다.
# 213
# 함수에 매개변수를 입력하지 않았다.
# 214
# 문자열과 숫자 더하기 시도
# 215
def print_with_smile(m):
    print(m,end=':D')
# 216 
print_with_smile("안녕하세요")
print()
# 217
def print_upper_price(c):
    print(c*1.3)
# 218
def print_sum(x,y):
    print(x+y)
# 219
def print_arithmetic_opearation(x,y):
    print(x+y);print(x-y);print(x*y);print(x/y)
# 220
def print_max(x,y,z):
    max_num=0
    if x>max_num:
        max_num=x
    if y>max_num:
        max_num=y
    if z>max_num:
        max_num=z
    print(max_num)

# 221~230
# 221
def print_reverse(msg):
    print(msg[::-1])  
print_reverse('python')  
# 222
def print_score(x):
    print(sum(x)/len(x)) 
print_score ([1, 2, 3])
# 223
def print_even(x):
    listx=[]
    for i in x:
        if i%2==0:
            listx.append(i)
    print(listx)
print_even ([1, 3, 2, 10, 12, 11, 15])
# 224
def print_keys(dict):
    for i in dict.keys():
        print(i)    
print_keys({"이름":"김말똥", "나이":30, "성별":0})
# 225
my_dict = {"10/26" : [100, 130, 100, 100],
           "10/27" : [10, 12, 10, 11]}
def print_value_by_key(dict,date):
    print(dict[date])
print_value_by_key  (my_dict, "10/26")
# 226
def print_5xn(string):
    num_five=int(len(string)/5)
    for i in range(num_five+1):
        print(string[i*5:i*5+5])
print_5xn("아이엠어보이유알어걸")
# 227
def printmxn(string,num):
    num_input=int(len(string)/num)
    for i in range(num_input+1):
        print(string[i*num:i*num+num])
printmxn("아이엠어보이유알어걸", 3)
# 228
def calc_monthly_salary(num):
    month_num=int(num/12)
    print(month_num)
    return month_num
calc_monthly_salary(12000000)
# 229
# 왼쪽 : 100, 오른쪽 : 200이 출력된다.
# 230
# 왼쪽 : 100, 오른쪽 : 200이 출력된다.

# 231~240
# 231
# 에러가 발생한다. Why? 함수 내의 정보를 함수 밖에서 사용하려 함.
# 232
def make_url(site):
    print(f'www.{site}.com')
make_url("naver")
# 233
def make_list(str1):
    print(list(str1))
make_list("abcd")
# 234
def pickup_even(num_list):
    even_list=[]
    for i in num_list:
        if i%2==0:
            even_list.append(i)
    print(even_list)
pickup_even([3, 4, 5, 6, 7, 8])
# 235
def convert_int(num):
    num=int(num.replace(',',''))
    print(num)
convert_int("1,234,567")
# 236
# 22가 출력된다.
# 237
# 22가 출력된다. 
# 238
# 140이 출력된다.
# 239
# 16이 출력된다.
# 240
# 28이 출력된다. 