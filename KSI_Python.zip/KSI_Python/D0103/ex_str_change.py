# 인덱스 원소/요소 읽기/추출
msg="pithon"

# i를 y로 변경하기 
# msg[1]='y' <- 미지원 불가 기능
# 따라서 문자열의 원소들을 분리해서 연결하는 방식 채택 (str+str+str)
print(msg[0]+'y'+msg[2:])
msg=msg[0]+'y'+msg[2:]