import csv

f=open('subwayfee.csv',encoding='utf-8-sig')
data=csv.reader(f)
header=next(data)
max_rate=0
rate=0

for row in data:
    
    # 4, 6 컬럼값을 정수로 변환 
    for i in range(4,8,2):
        row[i]=int(row[i])
    total_count=row[4]+row[6]
    
    # 유동인구가 10만명 이상인 최대 유임 승차 인원이 있는 역
    if(row[6]!=0) and (total_count>100000):
        rate=row[4]/total_count # 유임승차수 + 무임승차수
        
        if rate>max_rate:
            max_rate=rate
            max_row=row
            max_total_num=total_count
                      
print('-'*80)
print('최대 유임 승차역')
print(f"{max_row[1]},{max_row[3]}, 전체 인원 : {max_total_num:,}명,	"
      f"유임승차인원 : {max_row[4]:,}명, "
      f"유임승차 비율 : {round(max_rate	*100,1):,}%") 
f.close()
          