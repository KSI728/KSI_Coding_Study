# [Unit 24]
# [심사 문제 1]
input_nums="51900;83000;158000;367500;250000;59200;128500;1304000"
input_nums=input_nums.split(';')
input_nums=list(int(i) for i in input_nums)
input_nums.sort(reverse=True)

for i in input_nums:
    print('{0: >9,}'.format(i))
    