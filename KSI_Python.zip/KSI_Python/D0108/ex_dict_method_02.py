# dict 자료형 전용 함수(메서드)

data={'name':'한끼만','age':20,'job':'gambler'}

# [6] .update()
# dict에서 여러 개를 추가해주는 메서드
# str 타입의 key일 경우 ''를 따로 붙이지 않음 
data.update(haircolor='red')
print(data) 
# 내장함수 zip([],[],[],...,) 사용
result=zip([1,2,3],['a','b','c'],[100,200,300])
print(list(result))
data.update(zip(['A','B','C'],[100,200,300]))
print(data)

# [7] .pop(key) / .popitem()
# dict에서 원소/요소 꺼내기

# pop = key에 해당하는 값을 꺼내줌 -> 데이터가 제거됨
print(data.pop('name'))
print(data)

# popitem = 마지막 정보를 (key, value) 튜플로 묶어서 꺼내줌 -> 데이터가 제거됨
print(data.popitem())
print(data)

# [8] .clear() 
# dict에서 모든 원소/요소 삭제