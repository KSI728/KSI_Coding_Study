# range 객체 
# 숫자의 범위 생성
# 형식 : range(시작숫자, 끝숫자+1, 출력 범위)
# range 객체 덧셈,곱셈 불가능 -> 형변환 후 계산 
# 멤버 연산은 가능 
# range 객체 또한 원소/요소로 구성되어 있기 때문에 인덱싱과 슬라이싱 가능
num=range(1,51)
print(num[0])
print(type(num))
print(sum(num))

num1=range(50) #시작숫자를 따로 지정하지 않을 경우 시작은 0
print(num1[0])
print(len(num1))

num2=list(range(1,9)) #리스트로 형변환해서 확인할 수 있음
print(num2)

# [예제] 1~100 범위에서 3의 배수로만 구성된 데이터 추출
one=range(3,101,3)
print(list(one))