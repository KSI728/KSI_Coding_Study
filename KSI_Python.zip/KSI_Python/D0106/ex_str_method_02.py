# 메서드(method) : str 타입 전용 함수
# 문법 : 변수명.메서드명()

# [4] count()
# 원소의 갯수를 헤아리는 메서드 
data="PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP"
print(data.count('PP'))

# [5] replace('old','new')
# 특정 문자열을 다른 문자열로 변경하는 메서드
p="Pithon"
print(p.replace('i','y')) 
print(p) #replace() 메서드를 사용했다고 해서 변수의 원본 정보가 변경되는 것이 아님
p=p.replace('i','y') #이 경우에만 원본의 변경이 완료됨

# [응용] h -> H 대문자로 2번만 변경하기
happy="happy happy happy"
print(happy.replace('h','H',2))

# [6] split(분리구분 str)
# 여러 개의 str 분리해주는 메서드
# 기본값으로 공백문자 1개가 지정되어 있음 
# 나눠진 str들은 list에 담겨서 나옴
poppy=" "
print(poppy.split(" "))

# [실습] 
data2='에어컨 가격이 월 46,560원 36개월'
start=data2.find('46')
end=data2.find('원')
month=data2[start:end]
month=int(month.replace(',',''))
print(month)

mon=data2.find('36')
count=int(data2[mon:mon+2])
value=month*count