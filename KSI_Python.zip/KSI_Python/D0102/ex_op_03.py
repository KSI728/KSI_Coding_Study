# 논리연산자
'''
왼쪽 and 오른쪽 : 그리고
  True and True : True
  True and False : False
  False and False : False 
왼쪽 or 오른쪽 : 또는 
  True or True : True
  True or False : True
  False or False : False 
not [True/False] : 토글(Toggle), 결과값을 반대로 
  not True : False
  not False : True
'''

# [실습] 20대 남자인 경우 
gender="male"
age=27
print(gender=="male" and age>=20 and age<30)

# [실습] 20대 Human인 경우
print((gender=="male" or gender=="female") and (age>=20 and age<30))

# [not 응용]
# 마찬가지로 논리연산자에서 1은 True, 0은 False로 인식되어 적용된다.
# 추가로, int/float 에서 0 또는 0.을 제외하고 모두 True로 인식된다.
print(f'1:{not 1}')
print(not -1)

# [실습] 입력받은 데이터가 5 또는 10인 경우 체크 
data=int(input("숫자 하나를 입력하세요 : "))
print(data==5 or data==10)

# [실습] 대문자만 입력 받도록 체크 
data=input("알파벳 1개 입력 : ")
print(data>="A" and data<="Z")

# [실습] 임의의 숫자가 3의 배수 또는 5의 배수 여부 체크
data=int(input("숫자 하나를 입력 : "))
print(data%3==0 or data%5==0)
print(f'{not data%3 or not data%5}')

# [실습] 30대 여성 여부를 체크
gender="여"
age=25
print(gender=="여" and (age>=30 and age<=39))