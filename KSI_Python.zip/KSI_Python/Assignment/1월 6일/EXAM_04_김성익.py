# [문제 1]
# 1
good="Happy New Year 2022"
good=good.replace('2022','2023')
print(good)
# 2
chr="christmas"
chr=chr.upper()
print(chr)
# 3
phone_number="010-1111-2222"
phone_number=phone_number.split("-")
phone_number=''.join(phone_number)
print(phone_number)
# 4
count="5,969,782,550"
count=int(count.replace(',',''))
print(count,type(count))
# 5
rabbit="산토끼 토끼야 어디를 가느냐 폴짝 폴짝 뛰면서 어디를 가느냐"
print(rabbit.count("어디를"))
# 6
num="1,234,567,890"
num=num.split(',')
print(num)
# 7
email="koko@naver.com"
print(email.index('@'))
# 8 
weather="      오늘은 날씨가 너무 좋군요!!  "
weather=weather.strip()
print(len(weather))

# [문제 2]
print('★'.center(15))
print(('★'*3).center(15))
print(('★'*5).center(15))
print(('★'*7).center(15))
print(('★'*9).center(15))
print(('★'*11).center(15))
print(('★'*13).center(15))
print(('★'*15).center(15))
print(('★'*4).center(15))
print(('★'*4).center(15))
print("Merry Christmas".center(15))
print('2025'.center(15))

# [문제 3] 
# 1
numbers=input("숫자 2개를 다음과 같은 형식으로 입력해주세요(1,2) : ")
numbers=numbers.split(',')
print(f'{int(numbers[0])} + {int(numbers[1])} = {int(numbers[0])+int(numbers[1])}')
print(f'{int(numbers[0])} - {int(numbers[1])} = {int(numbers[0])-int(numbers[1])}')
print(f'{int(numbers[0])} * {int(numbers[1])} = {int(numbers[0])*int(numbers[1])}')
print(f'{int(numbers[0])} / {int(numbers[1])} = {int(numbers[0])/int(numbers[1])}')
# 2
like=input("좋아하는 단어를 영어로 입력해주세요 : ")
print(like.upper())
print(f"단어 안에 알파벳 'a'가 들어있는지 여부 : {'a' in like}")
# 3
korean="가나*마바사*자***파하"
idx=korean.index('*')
print(idx)
idx=korean.index('*',idx+1)
idx=korean.index('*',idx+1)
print(idx)
# 4
hello="Hello"
print(hello[::-1])