
public class Calculator {
	public Calculator() {
		// 클래스 내부의 메소드 호출 시 닷 연산자를 사용 안함
		powerOn();
	}
	
	void powerOn() {
		System.out.println("전원을 켭니다.");
	}
	
	void powerOff() {
		System.out.println("전원을 끕니다.");
	}
	
	int plus(int x, int y) {
		int result = x+y;
		return result; // 리턴값 지정
	}
	
	double divide(int x, int y) {
		double result = (double)x / (double)y;
		return result; // 리턴값 지정;
	}
}
