import csv

# encoding='utf-8-sig'로 \ufeff 삭제

# 파일 읽기 용도의 파일 객체 생성
fin=open('data/daegu.csv','r',encoding='utf-8-sig')
data=csv.reader(fin,delimiter=',')

# 파일 저장 용도의 파일 객체 생성 
fout=open('data/daegu-utf8.csv','w',newline='',encoding='utf-8-sig')
wr=csv.writer(fout)

# \t 삭제
for row in data:
    
    for i in range(len(row)):
        row[i]=row[i].replace('\t','')
    
    print(row)
    wr.writerow(row) # 한 행씩 파일로 저장 

# 항상 파일 닫아주기
fin.close()
fout.close()
print('파일 저장 완료')