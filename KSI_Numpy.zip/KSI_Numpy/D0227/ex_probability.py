import numpy as np
import matplotlib.pyplot as plt
from scipy import integrate

# 확률밀도함수와 확률분포함수
y_range = [3,5]

def g(y):
    if y_range[0] <= y <= y_range[1]:
        return (y-3) / 2
    else:
        return 0
    

def G(y):
    return integrate.quad(g,-np.inf,y)[0]


# 그래프 생성
ys=np.linspace(y_range[0],y_range[1],100)

fig=plt.figure(figsize=(10,6))
ax=fig.add_subplot(111)

ax.plot(ys, [g(y) for y in ys],
        label='g(y)', color='gray')
ax.plot(ys, [G(y) for y in ys],
        label='G(y)', ls='--', color='gray')
ax.hlines(0,2.8,5.2,alpha=0.3)
ax.vlines(ys.max(),0,1,linestyles=':',color='gray')

ax.set_xticks(np.arange(2.8,5.2,0.2))
ax.set_xlim(2.8,5.2)
ax.set_ylim(-0.1,1.1)
ax.legend()

plt.show()

# 결합확률밀도함수
x_range = [0, 2]
y_range = [0, 1]

def f_xy(x, y):
    if 0 <= y <= 1 and 0 <= x - y <= 1:
        return 4 * y * (x - y)
    else:
        return 0

XY = [x_range, y_range, f_xy]

xs = np.linspace(x_range[0], x_range[1], 200)
ys = np.linspace(y_range[0], y_range[1], 200)
pd = np.array([[f_xy(x, y) for y in ys] for x in xs])

fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111)

c = ax.pcolor(pd,cmap="viridis")
ax.set_xticks(np.linspace(0, 200, 3), minor=False)
ax.set_yticks(np.linspace(0, 200, 3), minor=False)
ax.set_xticklabels(np.linspace(0, 2, 3))
ax.set_yticklabels(np.linspace(0, 1, 3))
ax.invert_yaxis()
ax.xaxis.tick_top()
fig.colorbar(c, ax=ax)
plt.show()
